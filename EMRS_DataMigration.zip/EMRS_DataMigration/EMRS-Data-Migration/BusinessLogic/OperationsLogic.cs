﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class OperationsLogic
    {
        private readonly Operations operations;
        public OperationsLogic()
        {
            operations = new Operations();
        }

        public DataTable GetData(string sQuery, string Connectionstring)
        {

            try

            {

                return operations.Read(sQuery, Connectionstring);

            }

            catch

            {

                throw;

            }
        }

        public void UpdateData(string sQuery, string Connectionstring)
        {
            try

            {

                operations.Update(sQuery, Connectionstring);

            }

            catch

            {

                throw;

            }
        }

        public int InsertData(string sQuery, string Connectionstring)
        {
            try

            {

                return operations.Insert(sQuery, Connectionstring);

            }

            catch

            {

                throw;

            }

        }
    }
}
