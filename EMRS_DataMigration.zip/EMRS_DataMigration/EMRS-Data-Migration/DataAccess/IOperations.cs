﻿using System.Data;
namespace DataAccess
{
   public interface IOperations
    {
        DataTable Read(string selectQuery, string connectionString);
        void Update(string updateQuery, string connectionString);
        int Insert(string insertQuery, string connectionString);
        string ExecuteScaler(string commandText, string connectionString);
    }
}
