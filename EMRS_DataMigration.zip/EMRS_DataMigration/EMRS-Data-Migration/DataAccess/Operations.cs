﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class Operations : IOperations
    {

        readonly SqlConnection con = new SqlConnection();
        readonly DataTable dt = new DataTable();

        public string ExecuteScaler(string commandText, string connectionString)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(commandText, conn))
            {
                conn.Open();
                var result = cmd.ExecuteScalar();
                if (result == null)
                {
                    return null;
                }
                return result.ToString();
            }
        }

        public int Insert(string query, string constr)
        {
            try

            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();

                        int modified = cmd.ExecuteNonQuery();


                        return modified;
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public DataTable Read(string query, string constr)
        {

            try

            {
                DataTable dataTable = new DataTable();
                using (SqlConnection con = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    con.Open();
                    using (SqlDataReader oReader = cmd.ExecuteReader())
                    {
                        dataTable.Load(oReader);
                    }

                    return dataTable;
                }
            }

            catch (Exception ex)
            {

                throw ex;

            }
            finally
            {
                if (ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }

        public void Update(string query, string conStr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    string Updatequery = query;
                    con.Open();
                    using (SqlCommand command = new SqlCommand(Updatequery, con))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }

    }
}
