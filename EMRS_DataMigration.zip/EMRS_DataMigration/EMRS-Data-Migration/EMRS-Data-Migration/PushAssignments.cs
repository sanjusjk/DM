﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMRSAPI.AssignmentResponse;
using GraphWebAPI;

namespace EMRS_Data_Migration
{
    public class PushAssignments
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;

        public PushAssignments()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }

        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Assignements migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Assignements data migration--------------------");


            await PushAssignmentsAsync();



            LogHelper.Log(LogTarget.SQL, "------------------End Assignements migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Assignements data migration--------------------");
        }

        private async Task PushAssignmentsAsync()
        {
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Assignements from EMS--"));
            stringBuilder = new StringBuilder().Append("select * from (select")
                .Append(" D.dataid as AssignmentLocalId,")
                .Append(" I.emrsid as OccurrenceId,")
                .Append(" (case when D.deploymenttype= 'Local Assignment' then 'assignment'")
                .Append("  when D.deploymenttype= 'Deployment' then 'deployment'")
                .Append("   when D.deploymenttype= 'Recipient of information' then 'recipientOfInformation'")
                .Append("   else D.deploymenttype end) as AssignmentType,")
                .Append(" D.assignment_start_date as StartDate,")
                .Append("  D.assignment_end_date as EndDate,")
                .Append("  (case when D.deployee_status='Awaiting Approval' then 'awaitingapproval'")
                .Append("  when D.deployee_status = 'In Process' then 'inprocess' else D.deployee_status end")
                .Append(" ) as AssignmentStatus,")
                .Append(" (select emrsid from dbo.table_264 where  upper(level1name)=upper(D.assigned_function) and fk_table_263 in")
                .Append("  (select isnull(dataid,0) from dbo.table_263 where listname = 'AssignmentsFunction_Roles' and prevdataid=0)) as AssignmentFunctionId,")
                .Append(" (select emrsid from dbo.table_265 where upper(level2name)=upper(D.assigned_role) and")
                .Append("  fk_table_264 in (select dataid from dbo.table_264 where upper(level1name)=upper(D.assigned_function) and fk_table_263 in")
                .Append("  (select isnull(dataid,0) from dbo.table_263 where listname = 'AssignmentsFunction_Roles' and prevdataid=0)))as AssignmentRoleId,")
                .Append(" ( select emrsid from boardlistitems where name =L.locationtype and")
                .Append("  parentitemid in (select boardlistitemsid from boardlistitems")
                .Append("   where name like '%deployment location type%' and parentitemid=0)) as LocationTypeId,")
                .Append(" (select emrsid from boardlistitems where upper(name)=UPPER(L.country)")
                .Append("  and parentitemid in (select boardlistitemsid from boardlistitems where")
                .Append(" parentitemid in (select boardlistitemsid from boardlistitems where name like '%who_regions%' and parentitemid=0))) as CountryId,")
                .Append(" (select emrsid from boardlistitems where boardlistitemsid in(")
                .Append(" select parentitemid from boardlistitems where upper(name)=UPPER(L.country) ")
                .Append(" and  parentitemid in (select boardlistitemsid from boardlistitems where")
                .Append(" parentitemid in (select boardlistitemsid from boardlistitems where name like '%who_regions%' and parentitemid=0)))) as RegionId,")
                .Append(" (select top 1 emrsuserid from Users where name=C.email1 and synctoemrs=1) as [EmrsUser],D.emrsid")
                .Append(" from table_306 D")
                .Append("  Left Join Incidents I on I.incidentid=D.incidentid")
                .Append(" Left join table_304 L on L.dataid=D.fk_table_304")
                .Append(" Left join table_303 C on C.dataid=D.fk_table_303")
                .Append("  where D.prevdataid=0 ) as A ")
                .Append("  where A.emrsid is null and A.EmrsUser is not null and OccurrenceId is not null order by A.AssignmentLocalId desc");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            if (dataTable.Rows.Count > 0)
            {
                string token;
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Assignements to EMRS--"));
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentAPI"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        AssignmentsRequest AssignmentsRequest = new AssignmentsRequest()
                        {
                            AssignmentLocalId = Convert.ToInt32(dataTable.Rows[i]["AssignmentLocalId"]),
                            OccurrenceId = Convert.ToString(dataTable.Rows[i]["OccurrenceId"]),
                            AssignmentType = Convert.ToString(dataTable.Rows[i]["AssignmentType"]),
                            AssignmentFunctionId = dataTable.Rows[i]["AssignmentFunctionId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["AssignmentFunctionId"],
                            AssignmentRoleId = dataTable.Rows[i]["AssignmentRoleId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["AssignmentRoleId"],
                            StartDate = dataTable.Rows[i]["StartDate"] == DBNull.Value ? null : (DateTime?)dataTable.Rows[i]["StartDate"],
                            EndDate = dataTable.Rows[i]["EndDate"] == DBNull.Value ? null : (DateTime?)dataTable.Rows[i]["EndDate"],
                            AssignmentStatus = Convert.ToString(dataTable.Rows[i]["AssignmentStatus"])
                        };

                        if (dataTable.Rows[i]["RegionId"] != DBNull.Value && dataTable.Rows[i]["CountryId"] != DBNull.Value && dataTable.Rows[i]["LocationTypeId"] != DBNull.Value)
                        {
                            AssignmentsRequest.AssignmentLocation = new AssignmentLocation()
                            {
                                RegionId = Convert.ToInt32(dataTable.Rows[i]["RegionId"]),
                                CountryId = Convert.ToInt32(dataTable.Rows[i]["CountryId"]),
                                LocationTypeId = Convert.ToInt32(dataTable.Rows[i]["LocationTypeId"]),
                            };

                        }

                        token = await tokenService.GetToken();
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(AssignmentsRequest));
                        var url = string.Format(System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentAPI"), Convert.ToString(dataTable.Rows[i]["EmrsUser"]));
                        var res = await eMRSAPIs.PushOtherDataToEMRSAsync<AssignmentsRequest>(AssignmentsRequest, url, token);
                        Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(res.ToString());
                        if (myDeserializedClass != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.assignmentId));
                            stringBuilder = new StringBuilder().Append(String.Format("update table_306 set emrsid='{0}' WHERE dataid = {1}", Convert.ToString(myDeserializedClass.assignmentId), Convert.ToInt32(dataTable.Rows[i]["AssignmentLocalId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                       

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for EventID: " + Convert.ToString(dataTable.Rows[i]["AssignmentLocalId"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
        }

        public class AssignmentsRequest
        {
            public int AssignmentLocalId { get; set; }
            public string OccurrenceId { get; set; }
            public string AssignmentType { get; set; }
            public DateTime? StartDate { get; set; }
            public DateTime? EndDate { get; set; }
            public int? AssignmentFunctionId { get; set; }
            public int? AssignmentRoleId { get; set; }
            public AssignmentLocation AssignmentLocation { get; set; }
            public string AssignmentStatus { get; set; }
            public int ApplicationId { get => _ = 2; }
        }

        public class AssignmentLocation
        {
            public int RegionId { get; set; }
            public int CountryId { get; set; }
            public int LocationTypeId { get; set; }

        }


    }
}
