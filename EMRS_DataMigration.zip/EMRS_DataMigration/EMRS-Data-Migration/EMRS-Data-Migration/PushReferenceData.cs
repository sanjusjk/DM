﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using EMRSAPI.Model;
using EMRSAPI.RefDataResponse;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMRS_Data_Migration
{
    public class PushReferenceData
    {
        private DataTable dataTable;
        private readonly IOperations operations;
        private StringBuilder stringBuilder;
        private string EmrsToken;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;
        public PushReferenceData()
        {
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }
        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start refeence data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start refeence data migration--------------------");
            Console.WriteLine("\nPlease enter EMRS token :");
            var token = Console.ReadLine();
            EmrsToken = Convert.ToString(token);

            if (EmrsToken != "")
            {
                await PushPositionsAsync();
                await PushLocationTypeAsync();
                await PushFuntionsAsync();
                await PushRolesAsync();//after funtions
                await PushRegionsAsync();
                await PushCountries();//after region

                await PushHazards();
                await PushDiseaseCondition(); //after hazards
                await PushLanguages();
                await PushSyndroms();
                await PushSourceofInformation();
            }

            Console.WriteLine("\nPlease enter new EMRS token :");
            token = Console.ReadLine();
            EmrsToken = Convert.ToString(token);
            if (EmrsToken != "")
            {
                await PushAetiology();
            }

            LogHelper.Log(LogTarget.SQL, "------------------End refeence data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End refeence data migration--------------------");
        }
        private async Task PushPositionsAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start System position data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start System position data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Selecting Positions from EMRSDataMigration table"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,ApplicationId,OrderId,applyPermissions,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName")
            .Append(" from dbo.EMRSDataMigration where type=31 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Positions to EMRS--"));
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        SystemPosition systemPosition = new SystemPosition()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["VshocId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            ApplicationId = Convert.ToInt32(dataTable.Rows[i]["ApplicationId"])
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(systemPosition));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<SystemPosition>(systemPosition, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update Positions set emrsid={0} where positionid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End System Position data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End System Position data migration--------------------");
        }
        private async Task PushLocationTypeAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Location Type data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Location Type data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting LocationType from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,OrderId,applyPermissions,SyncTovShoc,VshocId,SyncToEms")
            .Append(" from dbo.EMRSDataMigration where type=30 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push LocationType to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        LocationType locationtype = new LocationType()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["VshocId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"]
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(locationtype));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<LocationType>(locationtype, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }
                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }

            LogHelper.Log(LogTarget.SQL, "------------------End Location Type data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Location Type data migration--------------------");
        }
        private async Task PushFuntionsAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Assignment Funtions data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Assignment Funtions data migration--------------------");
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Assignment Function from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select ID,Type,Code,Name,ApplicationId,IncidentSpecific,OrderId,applyPermissions,SyncTovShoc,VshocId,SyncToEms")
            .Append(" from dbo.EMRSDataMigration where type=33 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Assignment Function to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        AssignmentFuntions assignmentfuntions = new AssignmentFuntions()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["VshocId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            ApplicationId = Convert.ToInt32(dataTable.Rows[i]["ApplicationId"]),
                            IncidentSpecific = Convert.ToInt32(dataTable.Rows[i]["IncidentSpecific"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(assignmentfuntions));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<AssignmentFuntions>(assignmentfuntions, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update dbo.table_264 set emrsid={0} where dataid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                            stringBuilder = new StringBuilder().Append(String.Format("update dbo.EMRSDataMigration set AssignmentFunctionId={0} where fk_id={1} and Type=32", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "\nSynch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Assignment Funtions data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Assignment Funtions data migration--------------------");
        }
        private async Task PushRolesAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Assignment Roles data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Assignment Roles data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Assignment Role from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,ApplicationId,IncidentSpecific,OrderId,applyPermissions,SyncTovShoc,VshocId,SyncToEms,fk_id,AssignmentFunctionId")
            .Append(" from dbo.EMRSDataMigration where type=32 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Assignment Role to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        AssignmentRoles assignmentroles = new AssignmentRoles()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["VshocId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            ApplicationId = Convert.ToInt32(dataTable.Rows[i]["ApplicationId"]),
                            IncidentSpecific = Convert.ToInt32(dataTable.Rows[i]["IncidentSpecific"]),
                            AssignmentFunctionId = Convert.ToInt32(dataTable.Rows[i]["AssignmentFunctionId"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(assignmentroles));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<AssignmentRoles>(assignmentroles, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update dbo.table_265 set emrsid={0} where dataid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Assignment Roles data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Assignment Roles data migration--------------------");
        }
        private async Task PushSyndroms()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Syndroms data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Syndroms Roles data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Syndrome from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc")
            .Append(" from dbo.EMRSDataMigration where type=2 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Syndrome to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        Syndrome syndrome = new Syndrome()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["EmsId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            Application= Convert.ToString(dataTable.Rows[i]["Application"]),
                            Description = Convert.ToString(dataTable.Rows[i]["Description"])
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(syndrome));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<Syndrome>(syndrome, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update syndrome set emrsid={0} where syndromeID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Syndroms data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Syndroms Roles data migration--------------------");
        }
        private async Task PushSourceofInformation()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Source Of Information data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Source Of Information data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Source of Information from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc")
            .Append(" from dbo.EMRSDataMigration where type=3 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Source of Information to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        SourceofInformation sourceofinformation = new SourceofInformation()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["EmsId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            Description = Convert.ToString(dataTable.Rows[i]["Description"])
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(sourceofinformation));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<SourceofInformation>(sourceofinformation, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update sourceType_Lookup set emrsid={0} where sourceTypeID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Source Of Information data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Source Of Information data migration--------------------");
        }
        private async Task PushAetiology()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Aetiology data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Aetiology data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Aetiology from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc")
            .Append(" from dbo.EMRSDataMigration where type=14 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found.."));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Aetiology to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        string code = Convert.ToString(dataTable.Rows[i]["Code"]);
                        if (Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" || Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "NULL")
                        {
                            code = Convert.ToString(dataTable.Rows[i]["EmsId"]);
                        }

                        Aetiology aetiology = new Aetiology()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = code,
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            Description = Convert.ToString(dataTable.Rows[i]["Description"]) == "NULL" ? null : Convert.ToString(dataTable.Rows[i]["Description"])
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(aetiology));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<Aetiology>(aetiology, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update aetiology_Lookup set emrsid={0} where aetiologyID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Aetiology data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Aetiology data migration--------------------");
        }
        private async Task PushDiseaseCondition()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Disease Condition data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Disease Condition data migration--------------------");
            Console.WriteLine("\nSelecting Disease Condition from EMRSDataMigration table....");
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,IcdReference,IcdCategory,IcdChapter,IcdSubChapter,HazardId,OrderId,applyPermissions,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc")
            .Append(" from dbo.EMRSDataMigration where type=10 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Disease Condition to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        DiseaseCondition diseasecondition = new DiseaseCondition()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? Convert.ToString(dataTable.Rows[i]["EmsId"]) : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable.Rows[i]["Description"]),
                            Application = Convert.ToString(dataTable.Rows[i]["Application"]),
                            IcdReference = Convert.ToString(dataTable.Rows[i]["IcdReference"]),
                            IcdCategory = Convert.ToString(dataTable.Rows[i]["IcdCategory"]),
                            IcdChapter = Convert.ToString(dataTable.Rows[i]["IcdChapter"]),
                            IcdSubChapter = Convert.ToString(dataTable.Rows[i]["IcdSubChapter"]),
                            HazardId = Convert.ToInt32(dataTable.Rows[i]["HazardId"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"])
                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(diseasecondition));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<DiseaseCondition>(diseasecondition, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update disCon set emrsid={0} where disConID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Disease Condition data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Disease Condition data migration--------------------");
        }

        #region Common Ref Data in EMS and Vshoc
        private async Task PushRegionsAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Regions data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Regions data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Region from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,OrderId,applyPermissions,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName")
            .Append(" from dbo.EMRSDataMigration where type=4 and name<>''");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Region to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        //we can use LocationType model in  Region data 
                        LocationType locationtype = new LocationType()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable.Rows[i]["Description"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            vShocCode = Convert.ToString(dataTable.Rows[i]["vShocCode"])==""?null:Convert.ToString(dataTable.Rows[i]["vShocCode"]),
                            vShocName = Convert.ToString(dataTable.Rows[i]["vShocName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["vShocName"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            EmsCode = Convert.ToString(dataTable.Rows[i]["EmsCode"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsCode"]),
                            EmsName = Convert.ToString(dataTable.Rows[i]["EmsName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsName"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(locationtype));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<LocationType>(locationtype, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            if (dataTable.Rows[i]["VshocId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                                stringBuilder = new StringBuilder().Append(String.Format("update dbo.EMRSDataMigration set RegionId={0} where fk_id={1} and Type=1", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }
                            if (dataTable.Rows[i]["EmsId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update region_Lookup set emrsid={0} where regionID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        //Temp code
                        stringBuilder = new StringBuilder().Append(String.Format("update dbo.EMRSDataMigration set RegionId=(select emrsid from boardlistitems where boardlistitemsid={0}) where fk_id={0} and Type=1", Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                        operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }
                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Regions data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Regions data migration--------------------");
        }
        private async Task PushHazards()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Hazards data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Hazards data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Hazard from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName,OrderId,applyPermissions")
            .Append(" from dbo.EMRSDataMigration where type=6 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Hazard to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        //we can use Syndrome model in  Hazard data 
                        Syndrome syndrome = new Syndrome()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]).Trim() == "" ? "(undefined)" : Convert.ToString(dataTable.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable.Rows[i]["Description"]),
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            vShocCode = Convert.ToString(dataTable.Rows[i]["vShocCode"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["vShocCode"]),
                            vShocName = Convert.ToString(dataTable.Rows[i]["vShocName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["vShocName"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            EmsCode = Convert.ToString(dataTable.Rows[i]["EmsCode"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsCode"]),
                            EmsName = Convert.ToString(dataTable.Rows[i]["EmsName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsName"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"]),
                            Application= Convert.ToString(dataTable.Rows[i]["Application"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(syndrome));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<Syndrome>(syndrome, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            if (dataTable.Rows[i]["VshocId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }
                            if (dataTable.Rows[i]["EmsId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update hazard set emrsid={0} where hazardID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));

                                stringBuilder = new StringBuilder().Append(String.Format("update dbo.EMRSDataMigration set HazardId={0} where fk_id={1} and Type=10", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Hazards data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Hazards data migration--------------------");
        }
        private async Task PushLanguages()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Languages data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Languages data migration--------------------");

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Languages from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName,OrderId,applyPermissions")
            .Append(" from dbo.EMRSDataMigration where type=5 ");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));
            if (dataTable.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Languages to EMRS--"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        //we can you SourceofInformation model in  Languages data 
                        SourceofInformation sourceofinformation = new SourceofInformation()
                        {
                            Type = Convert.ToInt32(dataTable.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable.Rows[i]["Description"]),
                            SyncToEms = Convert.ToInt32(dataTable.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["EmsId"],
                            EmsCode = Convert.ToString(dataTable.Rows[i]["EmsCode"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsCode"]),
                            EmsName = Convert.ToString(dataTable.Rows[i]["EmsName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["EmsName"]),
                            VshocId = dataTable.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["VshocId"],
                            vShocCode = Convert.ToString(dataTable.Rows[i]["vShocCode"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["vShocCode"]),
                            vShocName = Convert.ToString(dataTable.Rows[i]["vShocName"]) == "" ? null : Convert.ToString(dataTable.Rows[i]["vShocName"]),
                            OrderId = dataTable.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable.Rows[i]["applyPermissions"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(sourceofinformation));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<SourceofInformation>(sourceofinformation, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            if (dataTable.Rows[i]["VshocId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }
                            if (dataTable.Rows[i]["EmsId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update sourceType_Lookup set emrsid={0} where sourceTypeID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["Name"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
            LogHelper.Log(LogTarget.SQL, "------------------End Languages data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Languages data migration--------------------");
        }
        private async Task PushCountries()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Countries data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Countries data migration--------------------");
            List<string> ExcludeDI = new List<string>();
            string CountryName = "";
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Countries data without SouvereginCountry from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select ID,Type,Code,Name,Description,Comments,IsOfficialUnCountry,IsWhoMemberState,OfficialName,ShortName,Iso2Code	" +
                ",Iso3Code,UnCode,Adm0Code,RegionId,UnicefRegionId,SouvereginCountryId,Timezone,Offset,PhoneCode,StartDate,EndDate," +
                "OrderId,applyPermissions,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName")
           .Append(" from dbo.EMRSDataMigration where type=1 and  ISNULL(SouvereginCountryId, '') = '' OR SouvereginCountryId= VshocId");
            DataTable dataTable_without_SouvereginCountryId = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Countries data with SouvereginCountry from EMRSDataMigration table--"));
            stringBuilder = new StringBuilder().Append("select ID,Type,Code,Name,Description,Comments,IsOfficialUnCountry,IsWhoMemberState,OfficialName,ShortName,Iso2Code	" +
            ",Iso3Code,UnCode,Adm0Code,RegionId,UnicefRegionId,SouvereginCountryId,Timezone,Offset,PhoneCode,StartDate,EndDate," +
             "OrderId,applyPermissions,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,VshocId,vShocCode,vShocName")
            .Append(" from dbo.EMRSDataMigration where type=1 and  ISNULL(SouvereginCountryId, '') <> '' and SouvereginCountryId<>isnull(vshocid,0)");
            DataTable dataTable_with_SouvereginCountryId = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"));

            if (dataTable_without_SouvereginCountryId.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable_without_SouvereginCountryId.Rows.Count + " records found without SouvereginCountry--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Countries without SouvereginCountry to EMRS--"));
                for (int i = 0; i < dataTable_without_SouvereginCountryId.Rows.Count; i++)
                {
                    try
                    {
                        CountryName = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Name"]);
                        Countries countries = new Countries()
                        {
                            Type = Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Description"]),
                            Comments = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Comments"]),
                            IsOfficialUnCountry = dataTable_without_SouvereginCountryId.Rows[i]["IsOfficialUnCountry"] == DBNull.Value ? null : (bool?)dataTable_without_SouvereginCountryId.Rows[i]["IsOfficialUnCountry"],
                            IsWhoMemberState = dataTable_without_SouvereginCountryId.Rows[i]["IsWhoMemberState"] == DBNull.Value ? null : (bool?)dataTable_without_SouvereginCountryId.Rows[i]["IsWhoMemberState"],
                            OfficialName = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["OfficialName"]),
                            ShortName = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["ShortName"]),
                            Iso2Code = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Iso2Code"]),
                            Iso3Code = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Iso3Code"]),
                            UnCode = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["UnCode"]),
                            Adm0Code = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Adm0Code"]),
                            RegionId = Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["RegionId"]),
                            UnicefRegion = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["UnicefRegionId"]),
                            SovereignCountryId = null,
                            Timezone = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["Timezone"]),
                            Offset = dataTable_without_SouvereginCountryId.Rows[i]["Offset"] == DBNull.Value ? null : (int?)dataTable_without_SouvereginCountryId.Rows[i]["Offset"],
                            PhoneCode = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["PhoneCode"]),
                            StartDate = dataTable_without_SouvereginCountryId.Rows[i]["StartDate"] == DBNull.Value ? null : (DateTime?)dataTable_without_SouvereginCountryId.Rows[i]["StartDate"],
                            EndDate = dataTable_without_SouvereginCountryId.Rows[i]["EndDate"] == DBNull.Value ? null : (DateTime?)dataTable_without_SouvereginCountryId.Rows[i]["EndDate"],
                            SyncToEms = Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable_without_SouvereginCountryId.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable_without_SouvereginCountryId.Rows[i]["EmsId"],
                            EmsCode = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["EmsCode"]) == "" ? null : Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["EmsCode"]),
                            EmsName = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["EmsName"]) == "" ? null : Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["EmsName"]),
                            VshocId = dataTable_without_SouvereginCountryId.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable_without_SouvereginCountryId.Rows[i]["VshocId"],
                            vShocCode = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["vShocCode"]) == "" ? null : Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["vShocCode"]),
                            vShocName = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["vShocName"]) == "" ? null : Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["vShocName"]),
                            OrderId = dataTable_without_SouvereginCountryId.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable_without_SouvereginCountryId.Rows[i]["OrderId"],
                            applyPermissions = Convert.ToString(dataTable_without_SouvereginCountryId.Rows[i]["applyPermissions"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(countries));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<Countries>(countries, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            if (dataTable_without_SouvereginCountryId.Rows[i]["VshocId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                                stringBuilder = new StringBuilder();
                                stringBuilder.Append("SouvereginCountryId=" + Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["VshocId"]));

                                if (ExcludeDI.Count() > 0)
                                {
                                    stringBuilder.Append(" and ID not in (" + string.Join(",", ExcludeDI) + ") ");
                                }
                                DataRow[] rows = dataTable_with_SouvereginCountryId.Select(stringBuilder.ToString());
                                if (rows != null)
                                {
                                    for (int j = 0; j < rows.Length; j++)
                                    {
                                        ExcludeDI.Add(Convert.ToString(rows[j]["ID"]));
                                        rows[j]["SouvereginCountryId"] = Convert.ToInt32(myDeserializedClass.value.Id);
                                    }

                                }

                            }
                            if (dataTable_without_SouvereginCountryId.Rows[i]["EmsId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update country_Lookup set emrsid={0} where countryID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable_without_SouvereginCountryId.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));


                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + CountryName + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable_without_SouvereginCountryId.Rows.Count);

                }

            }


            if (dataTable_with_SouvereginCountryId.Rows.Count > 0)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable_with_SouvereginCountryId.Rows.Count + " records found with SouvereginCountry--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Countries with SouvereginCountry to EMRS"));
                for (int i = 0; i < dataTable_with_SouvereginCountryId.Rows.Count; i++)
                {
                    try
                    {
                        CountryName = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Name"]);
                        Countries countries = new Countries()
                        {
                            Type = Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["Type"]),
                            Code = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Code"]),
                            Name = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Name"]),
                            Description = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Description"]),
                            Comments = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Comments"]),
                            IsOfficialUnCountry = Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["IsOfficialUnCountry"]) == 1 ? true : false,
                            IsWhoMemberState = dataTable_with_SouvereginCountryId.Rows[i]["IsWhoMemberState"] == DBNull.Value?false: Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["IsWhoMemberState"]) == 1 ? true : false,
                            OfficialName = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["OfficialName"]),
                            ShortName = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["ShortName"]),
                            Iso2Code = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Iso2Code"]),
                            Iso3Code = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Iso3Code"]),
                            UnCode = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["UnCode"]),
                            Adm0Code = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Adm0Code"]),
                            RegionId = Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["RegionId"]),
                            UnicefRegion = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["UnicefRegionId"]),
                            SovereignCountryId = dataTable_with_SouvereginCountryId.Rows[i]["SouvereginCountryId"] == DBNull.Value ? null : (int?)dataTable_with_SouvereginCountryId.Rows[i]["SouvereginCountryId"],
                            Timezone = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["Timezone"]),
                            Offset = dataTable_with_SouvereginCountryId.Rows[i]["Offset"] == DBNull.Value ? null : (int?)dataTable_with_SouvereginCountryId.Rows[i]["Offset"],
                            PhoneCode = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["PhoneCode"]),
                            StartDate = dataTable_with_SouvereginCountryId.Rows[i]["StartDate"] == DBNull.Value ? null : (DateTime?)dataTable_with_SouvereginCountryId.Rows[i]["StartDate"],
                            EndDate = dataTable_with_SouvereginCountryId.Rows[i]["EndDate"] == DBNull.Value ? null : (DateTime?)dataTable_with_SouvereginCountryId.Rows[i]["EndDate"],
                            SyncToEms = Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["SyncToEms"]) == 1 ? true : false,
                            SyncTovShoc = Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["SyncTovShoc"]) == 1 ? true : false,
                            EmsId = dataTable_with_SouvereginCountryId.Rows[i]["EmsId"] == DBNull.Value ? null : (int?)dataTable_with_SouvereginCountryId.Rows[i]["EmsId"],
                            EmsCode = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["EmsCode"]),
                            EmsName = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["EmsName"]),
                            VshocId = dataTable_with_SouvereginCountryId.Rows[i]["VshocId"] == DBNull.Value ? null : (int?)dataTable_with_SouvereginCountryId.Rows[i]["VshocId"],
                            vShocCode = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["vShocCode"]),
                            vShocName = Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["vShocName"]),
                            OrderId = dataTable_with_SouvereginCountryId.Rows[i]["OrderId"] == DBNull.Value ? null : (int?)dataTable_with_SouvereginCountryId.Rows[i]["OrderId"],
                            applyPermissions =  Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["applyPermissions"])==""?"0": Convert.ToString(dataTable_with_SouvereginCountryId.Rows[i]["applyPermissions"])

                        };
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(countries));
                        Root myDeserializedClass = await eMRSAPIs.PushDataToEMRSAsync<Countries>(countries, System.Configuration.ConfigurationManager.AppSettings.Get("ReferenceDataAPI"), EmrsToken);
                        if (myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            if (dataTable_with_SouvereginCountryId.Rows[i]["VshocId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update boardlistitems set emrsid={0} where boardlistitemsid={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["VshocId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }
                            if (dataTable_with_SouvereginCountryId.Rows[i]["EmsId"] != DBNull.Value)
                            {
                                stringBuilder = new StringBuilder().Append(String.Format("update country_Lookup set emrsid={0} where countryID={1}", Convert.ToInt32(myDeserializedClass.value.Id), Convert.ToInt32(dataTable_with_SouvereginCountryId.Rows[i]["EmsId"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + CountryName + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable_with_SouvereginCountryId.Rows.Count);

                }

            }


            LogHelper.Log(LogTarget.SQL, "------------------End Countries data migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Countries data migration--------------------");

        }
        #endregion
    }
}
