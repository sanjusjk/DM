﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using CustomLogs;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace EMRS_Data_Migration
{
    public class PushContactDataToUsers
    {
        private DataTable dataTable;
        private readonly IOperations operations;
        private StringBuilder stringBuilder;

        public PushContactDataToUsers()
        {
            operations = new Operations();
        }

        public void StartProcess()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start table_303 data migration--------------------");
            Migrate();
            LogHelper.Log(LogTarget.SQL, "------------------End table_303 data migration--------------------");
        }

        private void Migrate()
        {
            try
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Users from [table_303] table with Azure id's which are not avail in [Users] table--"));
                stringBuilder = new StringBuilder();
                stringBuilder.Append("select p.email1,p.firstname,p.familyname, temp.UsersObjectId,p.userid,p.vshocuser")
                    .Append(" FROM dbo.table_303 AS p")
                    .Append(" INNER JOIN WHOAzureUsers AS temp ON temp.[UserEmail] = p.[email1]")
                    .Append(" FULL OUTER JOIN Users AS U ON U.name=p.email1")
                    .Append(" where prevdataid=0 and u.name is NULL");

                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Inserting Users from [table_303] table with Azure id's which are not avail into [Users] table--"));
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        try
                        {
                            stringBuilder = new StringBuilder();
                            Guid guserid = Guid.NewGuid();
                            string email = dataTable.Rows[i].ItemArray[0].ToString();
                            string firstName = Convert.ToString(dataTable.Rows[i].ItemArray[1].ToString()).Replace("'", "''");
                            string familyName = Convert.ToString(dataTable.Rows[i].ItemArray[2].ToString()).Replace("'", "''");
                            string emrsuserid = dataTable.Rows[i].ItemArray[3].ToString();
                            string realName = familyName.ToUpper() + ", " + firstName;
                            DateTime dateTime = Convert.ToDateTime("1900-01-03T00:00:00.000");

                            string cnt = Convert.ToString(operations.ExecuteScaler("Select count(name) from [dbo].[Users] where name like '%" + email + "%' ", ConfigurationManager.AppSettings.Get("vShocDbConnection")));

                            if (cnt == "" || cnt == "0")
                            {
                                stringBuilder.Append("INSERT [dbo].[Users] ([name], [password], [primaryemail], [multipleuser], [color], [administrator], [deletable], [failedattempts], [passwordexpiration], [lockoutexpiration], [accountlocked], [mustchangepwd], [salt], [dualcommit], [langlcid], [formatlcid], [timezoneoverride], [timezone], [daylight], [lockoutset], [passwordset], [lastattemptedlogin], [lastlogin], [lcid], [timezoneid], [comments], [realname], [location], [officephone], [mobilephone], [officephoneisdefault], [department], [supervisor], [attachmentid], [organization], [overrideorglocale], [disableuserupdate], [allowinactivityexpiration], [accounttype], [defaultincidentid], [globaluserid], [datecreated], [expirationdate], [supervisoremail], [supervisorphone], [lastpositionid], [emrsuserid])")
                                                               .Append("VALUES ( '" + email + "', N'', '" + email + "', 0, NULL, 0, 1, 0, NULL, NULL, 0, 0, N'', 0, 0, 0, 0, 60, 1, NULL,'" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "', NULL, NULL, NULL, NULL, N' ','" + realName + "', NULL, NULL, NULL, 1, NULL, NULL, 0, NULL, 0, 0, 1, 0, NULL,'" + guserid.ToString() + "', NULL, NULL, NULL, NULL, NULL,'" + emrsuserid + "')");
                                operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }
                            else
                            {
                                stringBuilder.Append("update [dbo].[Users] set [emrsuserid]='"+ emrsuserid + "' where name='"+ email + "'");
                                operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                            }

                            ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "SQL Exception - \nError:" + ex.Message));
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "SQL Exception - \nError:" + ex.Message));
            }

        }
    }
}
