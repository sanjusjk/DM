﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using EMRSAPI.EmergencyResponse;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMRS_Data_Migration
{
    public class PushEmergencies
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;
        public PushEmergencies()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }
        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start emergencies migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start emergencies data migration--------------------");


            await PushEmergencyAsync();



            LogHelper.Log(LogTarget.SQL, "------------------End emergencies migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End emergencies data migration--------------------");
        }
        private async Task PushEmergencyAsync()
        {
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting emergency from vshoc--"));
            stringBuilder = new StringBuilder().Append("select t.dataid,i.incidentid,i.name as OccurrenceName,'Emergency' as OccurrenceType")
                .Append(" from table_280 t inner join Incidents i on i.incidentid=t.systemincidentid where t.prevdataid=0 and i.emrsid is null");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            if (dataTable.Rows.Count > 0)
            {

                //query for fetching countries
                StringBuilder countrystringBuilder = new StringBuilder();
                countrystringBuilder.Append("select CN.name,CN.emrsid,T.incid from table_282 T ")
                    .Append("inner join ")
                    .Append("(select emrsid,name from BoardListItems ")
                    .Append("where parentitemid in ( ")
                    .Append("select boardlistitemsid from BoardListItems where parentitemid in (")
                    .Append("select boardlistitemsid from BoardListItems where name = 'Who_regions'")
                    .Append(")")
                    .Append(")")
                    .Append("and name<>'') CN on CN.name = T.ctryid");
                DataTable dtcountries; string token;
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push emergency to EMRS--"));
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {

                    try
                    {

                        OccurrenceRequest occurrenceRequest = new OccurrenceRequest()
                        {
                            OccurrenceName = Convert.ToString(dataTable.Rows[i]["OccurrenceName"]),
                            OccurrenceType = Convert.ToString(dataTable.Rows[i]["OccurrenceType"]),
                            SourceReferenceId = Convert.ToInt32(dataTable.Rows[i]["incidentid"])
                        };

                        dtcountries = operations.Read(LogHelper.Log(LogTarget.SQL, countrystringBuilder.ToString() + " where  T.incid=" + Convert.ToInt32(dataTable.Rows[i]["incidentid"]) + " "), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        if (dtcountries.Rows.Count > 0)
                        {
                            for (int j = 0; j < dtcountries.Rows.Count; j++)
                            {
                                if (dtcountries.Rows[j]["emrsid"] != DBNull.Value && Convert.ToInt32(dtcountries.Rows[j]["emrsid"]) != 0)
                                {
                                    occurrenceRequest.Country.Add(Convert.ToInt32(dtcountries.Rows[j]["emrsid"]));
                                }
                            }
                        }
                        token = await tokenService.GetToken();
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(occurrenceRequest));
                        var res = await eMRSAPIs.PushOtherDataToEMRSAsync<OccurrenceRequest>(occurrenceRequest, System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"), token);
                        Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(res.ToString());
                        if (myDeserializedClass != null && myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update Incidents set emrsid='{0}' where incidentid={1}", Convert.ToString(myDeserializedClass.value.id), Convert.ToInt32(dataTable.Rows[i]["incidentid"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["OccurrenceName"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }


            }
        }
    }
}
public class OccurrenceRequest
{
    public string OccurrenceName { get; set; }
    public string OccurrenceType { get; set; }
    public int SourceReferenceId { get; set; }
    public List<int> Country = new List<int>();
}
