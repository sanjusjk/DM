﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMRSAPI.EmergencyResponse;

namespace EMRS_Data_Migration
{
    public class PushEvents
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;
        public PushEvents()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }

        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Events migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start Events data migration--------------------");


            await PushEventsAsync();



            LogHelper.Log(LogTarget.SQL, "------------------End Events migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End Events data migration--------------------");
        }

        private async Task PushEventsAsync()
        {
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Events from EMS--"));
            stringBuilder = new StringBuilder().Append("select eventID,[eventDisplayID] as OccurrenceName,c.emrsID ,'Event' as OccurrenceType")
               .Append(" from [event] e inner join country_Lookup c on c.countryID = e.[countryID] and e.emrsid is null");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
            if (dataTable.Rows.Count > 0)
            {
                string token;
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push Events to EMRS--"));
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        EventOccurrenceRequest eventOccurrenceRequest = new EventOccurrenceRequest()
                        {
                            OccurrenceName = Convert.ToString(dataTable.Rows[i]["OccurrenceName"]),
                            OccurrenceType = Convert.ToString(dataTable.Rows[i]["OccurrenceType"]),
                            SourceReferenceId = Convert.ToInt32(dataTable.Rows[i]["eventID"]),
                            Country = dataTable.Rows[i]["emrsID"] == DBNull.Value?null :(int?)dataTable.Rows[i]["emrsID"]
                        };
                        token = await tokenService.GetToken();
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(eventOccurrenceRequest));
                        var res = await eMRSAPIs.PushOtherDataToEMRSAsync<EventOccurrenceRequest>(eventOccurrenceRequest, System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"), token);
                        Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(res.ToString());
                        if (myDeserializedClass != null && myDeserializedClass.value != null)
                        {
                            LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                            stringBuilder = new StringBuilder().Append(String.Format("update event set emrsid='{0}' where eventID={1}", Convert.ToString(myDeserializedClass.value.id), Convert.ToInt32(dataTable.Rows[i]["eventID"])));
                            operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["OccurrenceName"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }
            }
        }
    }

    public class EventOccurrenceRequest
    {
        public string OccurrenceName { get; set; }
        public string OccurrenceType { get; set; }
        public int SourceReferenceId { get; set; }
        public int? Country { get; set; }
    }
}
