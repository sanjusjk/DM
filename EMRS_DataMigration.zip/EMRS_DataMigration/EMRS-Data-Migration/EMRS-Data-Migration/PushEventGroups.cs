﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMRSAPI.EmergencyResponse;

namespace EMRS_Data_Migration
{
    public class PushEventGroups
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;

        public PushEventGroups()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }

        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start EventGroup migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start EventGroup data migration--------------------");


            await PushEventGroupsAsync();



            LogHelper.Log(LogTarget.SQL, "------------------End EventGroup migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End EventGroup data migration--------------------");
        }

        private async Task PushEventGroupsAsync()
        {
            try
            {

                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting EventGroup from EMS--"));
                stringBuilder = new StringBuilder().Append("select el.eventlinkid,el.eventlinktitle as OccurrenceName,'EventGroup' as OccurrenceType from eventlink el")
                    .Append(" inner join eventlink_xwalk ex on ex.eventlinkid = el.eventlinkid")
                .Append(" inner join event e on e.eventid = ex.eventid where el.emrsid is null")
                .Append(" group by el.eventlinkid,el.eventlinktitle");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                if (dataTable.Rows.Count > 0)
                {

                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {

                        StringBuilder SBEmrsID = new StringBuilder().Append("SELECT STUFF((select ','+e.emrsID FROM event e ")
                       .Append(" INNER JOIN [eventLink_XWalk] ex ON ex.eventID=e.eventID")
                       .Append(" WHERE ex.eventLinkID=" + Convert.ToInt32(dataTable.Rows[i]["eventlinkid"]) + " ")
                       .Append(" FOR XML PATH('')),1,1,'') As emrsID");
                        DataTable dtEmrsID; string token;
                        LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--");
                        LogHelper.Log(LogTarget.API, "\n--Push EventGroup to EMRS--");
                        LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"));
                        try
                        {
                            EventGroupOccurrenceRequest eventGroupOccurrenceRequest = new EventGroupOccurrenceRequest()
                            {
                                OccurrenceName = Convert.ToString(dataTable.Rows[i]["OccurrenceName"]),
                                OccurrenceType = Convert.ToString(dataTable.Rows[i]["OccurrenceType"]),
                                SourceReferenceId = Convert.ToInt32(dataTable.Rows[i]["eventlinkid"])
                            };

                            dtEmrsID = operations.Read(LogHelper.Log(LogTarget.SQL, SBEmrsID.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            if (dtEmrsID.Rows.Count > 0)
                            {

                                foreach (DataRow row in dtEmrsID.Rows)
                                {
                                    if (row["emrsID"] != DBNull.Value)  //If row["emrsID"] is not null
                                    {
                                        string[] stringArray = row["emrsID"].ToString().Split(',').ToArray();
                                        eventGroupOccurrenceRequest.EventMemberOccurrenceIds = stringArray;
                                    }
                                    else
                                    {
                                        eventGroupOccurrenceRequest.EventMemberOccurrenceIds = Array.Empty<string>(); //if row["emrsID"] is null, it will make an empty array
                                    }
                                    eventGroupOccurrenceRequest.Country = null;
                                }

                            }
                            token = await tokenService.GetToken();
                            LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(eventGroupOccurrenceRequest));
                            var res = await eMRSAPIs.PushOtherDataToEMRSAsync<EventGroupOccurrenceRequest>(eventGroupOccurrenceRequest, System.Configuration.ConfigurationManager.AppSettings.Get("OccurrenceAPI"), token);
                            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(res.ToString());
                            if (myDeserializedClass != null && myDeserializedClass.value != null)
                            {
                                LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.value));
                                stringBuilder = new StringBuilder().Append(String.Format("update eventlink set emrsid='{0}' where eventlinkid={1}", Convert.ToString(myDeserializedClass.value.id), Convert.ToInt32(dataTable.Rows[i]["eventlinkid"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["OccurrenceName"]) + "  \nError:" + ex.Message));
                        }

                        ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                    }


                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "Synch failed \nError:" + ex.Message));
            }

        }

        public class EventGroupOccurrenceRequest
        {
            public string OccurrenceName { get; set; }
            public string OccurrenceType { get; set; }
            public int SourceReferenceId { get; set; }
            public string[] EventMemberOccurrenceIds { get; set; }
            public int? Country { get; set; }
        }
    }
}
