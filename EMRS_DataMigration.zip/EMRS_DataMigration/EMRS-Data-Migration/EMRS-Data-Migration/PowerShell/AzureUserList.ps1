﻿#uncomment the below two lines when you are executing script first time
#Install-Module AzureAD -Force
#Import-Module AzureRM

Install-Module AzureAD -Force

Import-Module AzureRM

Connect-AzureAD 

$output = @()

$users = Get-AzureADUser -All $true

foreach ($user in $users) {
  
    $data = New-Object -TypeName psobject

    $data | Add-Member -MemberType NoteProperty -Name UsersObjectId -Value $user.ObjectId
	if (($user.UserPrincipalName).contains("#EXT#")) 
	{ 
	    $string = $user.UserPrincipalName
        $split = $string.Split("#")
        $split1 = $split[0].Split("_")[-1]
        $domain = $split1

        $split1 = $split[0].Split("_")
        $id = $split[0].Substring(0,$split[0].LastIndexOf("_"))+"@"
        $test = $id+$domain 

        $data | Add-Member -MemberType NoteProperty -Name UserEmail -Value $test 
	}
    else
    {
     $data | Add-Member -MemberType NoteProperty -Name UserEmail -Value $user.UserPrincipalName
    }
    $data | Add-Member -MemberType NoteProperty -Name UserType -Value $user.UserType
    $data | Add-Member -MemberType NoteProperty -Name Email -Value $user.Email
  

    $output += $data

}

$output | Export-Csv -Path D:\outputWHO.csv -NoTypeInformation