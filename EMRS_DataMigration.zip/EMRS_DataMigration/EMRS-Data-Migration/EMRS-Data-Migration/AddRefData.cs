﻿using CustomLogs;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMRS_Data_Migration
{
    public class AddRefData
    {
        private IOperations operations = new Operations();
        private StringBuilder stringBuilder;
        private DataTable dataTable;

        public AddRefData()
        {
            operations = new Operations();
        }

        public void StartProcess()
        {

            LogHelper.Log(LogTarget.SQL, "------------------Prepare reference data for migration--------------------");
            try
            {
                #region Reference Data 


                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Removing ems reference data from EMRSDataMigration table--"));
                //Delete existing ems records (not common) from EMRSDataMigration table. if any 
                operations.Update(LogHelper.Log(LogTarget.SQL, "delete from [dbo].[EMRSDataMigration] where [Type] in (2,3,14,10,33,32)"), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                //insert assignment funtion into EMRSDataMigration table
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Insert assignment funtion into EMRSDataMigration table--"));
                stringBuilder = new StringBuilder();
                stringBuilder.Append("insert into [dbo].[EMRSDataMigration] (Type,Code,Name,ApplicationId,IncidentSpecific,OrderId,applyPermissions,SyncTovShoc,VshocId,SyncToEms)")
                    .Append("select 33,CAST(dataid as nvarchar(10)),level1name,2,incidentspecific,orderid,apply_permissions,1,dataid,0 from dbo.table_264 where fk_table_263 in ")
                    .Append("(select isnull(dataid,0) from dbo.table_263 (NOLOCK)  where listname = 'AssignmentsFunction_Roles' and prevdataid=0)");
                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                //insert assignment role into EMRSDataMigration table
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Insert assignment role into EMRSDataMigration table--"));
                stringBuilder = new StringBuilder();
                stringBuilder.Append("insert into [dbo].[EMRSDataMigration] (Type,Code,Name,ApplicationId,IncidentSpecific,OrderId,applyPermissions,SyncTovShoc,VshocId,SyncToEms,fk_id)")
                    .Append("select 32,CAST(dataid as nvarchar(10)),level2name,2,incidentspecific,orderid,apply_permissions,1,dataid,0,fk_table_264 from dbo.table_265 where fk_table_263 in ")
                    .Append("(select isnull(dataid,0) from dbo.table_263 (NOLOCK)  where listname = 'AssignmentsFunction_Roles' and prevdataid=0)");
                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                #region insert Syndrome

                Console.WriteLine(LogHelper.Log(LogTarget.SQL,"\n --Selecting Syndrome record from ems database--"));
                //insert Syndrome from ems to EMRSDataMigration table
                stringBuilder = new StringBuilder().Append("select 2 as [Type],syndromeCode as [Code],syndromeName as [Name]")
                    .Append(",syndromeDesc as [Description], application as [Application],1 as [SyncToEms],syndromeID as [EmsId],syndromeCode as [EmsCode],")
                    .Append("syndromeName as [EmsName],0 as [SyncTovShoc]")
                    .Append("from syndrome");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n --Insert syndrom into EMRSDataMigration table--"));
                    //Progress.WriteProgressBar(dataTable.Rows.Count);
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        stringBuilder = new StringBuilder().Append(" Insert into [dbo].[EMRSDataMigration]")
                            .Append(" (Type,Code,Name,Description,Application,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc)")
                            .Append(" values (" + dataTable.Rows[i]["Type"] + ",'" + Convert.ToString(dataTable.Rows[i]["Code"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["Name"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["Description"]).Replace("'", "''") + "'" +
                            ",'" + Convert.ToString(dataTable.Rows[i]["Application"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncToEms"] + "," +
                            "" + dataTable.Rows[i]["EmsId"] + ",'" + Convert.ToString(dataTable.Rows[i]["EmsCode"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["EmsName"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncTovShoc"] + ")");
                        operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                    }
                }

                #endregion

                #region Source of Information
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Source of Information record from ems database--"));
                //insert Source of Information from ems to EMRSDataMigration table
                stringBuilder = new StringBuilder().Append("select 3 as [Type],sourceTypeCode as [Code],sourceTypeName as [Name]")
                    .Append(",sourceTypeDesc as [Description],1 as [SyncToEms],sourceTypeID as [EmsId],sourceTypeCode as [EmsCode],")
                    .Append("sourceTypeName as [EmsName],0 as [SyncTovShoc]")
                    .Append("from sourceType_Lookup");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Insert Source of Information into EMRSDataMigration table--"));
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        stringBuilder = new StringBuilder().Append(" Insert into [dbo].[EMRSDataMigration]")
                            .Append(" (Type,Code,Name,Description,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc)")
                            .Append(" values (" + dataTable.Rows[i]["Type"] + ",'" + Convert.ToString(dataTable.Rows[i]["Code"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["Name"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["Description"]).Replace("'", "''") + "'" +
                            "," + dataTable.Rows[i]["SyncToEms"] + "," +
                            "" + dataTable.Rows[i]["EmsId"] + ",'" + Convert.ToString(dataTable.Rows[i]["EmsCode"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["EmsName"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncTovShoc"] + ")");
                        operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                    }
                }
                #endregion

                #region Aetiology
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Aetiology record from ems database--"));
                //insert Aetiology from ems to EMRSDataMigration table
                stringBuilder = new StringBuilder().Append("select 14 as [Type],Code as [Code],name as [Name]")
                    .Append(",description as [Description],1 as [SyncToEms],aetiologyID as [EmsId],Code as [EmsCode],")
                    .Append("name as [EmsName],0 as [SyncTovShoc]")
                    .Append("from aetiology_Lookup where emrsid is null");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Insert Aetiology into EMRSDataMigration table--"));
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        stringBuilder = new StringBuilder().Append(" Insert into [dbo].[EMRSDataMigration]")
                            .Append(" (Type,Code,Name,Description,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc)")
                            .Append(" values (" + dataTable.Rows[i]["Type"] + ",'" + Convert.ToString(dataTable.Rows[i]["Code"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["Name"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["Description"]).Replace("'", "''") + "'" +
                            "," + dataTable.Rows[i]["SyncToEms"] + "," +
                            "" + dataTable.Rows[i]["EmsId"] + ",'" + Convert.ToString(dataTable.Rows[i]["EmsCode"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["EmsName"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncTovShoc"] + ")");
                        operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                    }
                }
                #endregion

                #region Disease Condition
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting Disease Condition record from ems database--"));
                //insert Disease Condition from ems to EMRSDataMigration table
                stringBuilder = new StringBuilder().Append("select 10 as [Type],disConCode as [Code],disConName as [Name]")
                    .Append(",disConDesc as [Description], disConApplication as [Application],IcdReference,ICDCategoryID as [IcdCategory],ICDChapterID as [IcdChapter]")
                    .Append(",ICDSubChapterID as [IcdSubChapter],1 as [SyncToEms],disConID as [EmsId],disConCode as [EmsCode],")
                    .Append("disConName as [EmsName],0 as [SyncTovShoc],hazardID as [fk_id]")
                    .Append("from disCon");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Insert Disease Condition into EMRSDataMigration table--"));
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        stringBuilder = new StringBuilder().Append(" Insert into [dbo].[EMRSDataMigration]")
                            .Append(" (Type,Code,Name,Description,Application,IcdReference,IcdCategory,IcdChapter,IcdSubChapter,SyncToEms,EmsId,EmsCode,EmsName,SyncTovShoc,fk_id)")
                            .Append(" values (" + dataTable.Rows[i]["Type"] + ",'" + Convert.ToString(dataTable.Rows[i]["Code"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["Name"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["Description"]).Replace("'", "''") + "'" +
                            ",'" + Convert.ToString(dataTable.Rows[i]["Application"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["IcdReference"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["IcdCategory"]).Replace("'", "''") + "','" + Convert.ToString(dataTable.Rows[i]["IcdChapter"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["IcdSubChapter"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncToEms"] + "," +
                            "" + dataTable.Rows[i]["EmsId"] + ",'" + Convert.ToString(dataTable.Rows[i]["EmsCode"]).Replace("'", "''") + "'," +
                            "'" + Convert.ToString(dataTable.Rows[i]["EmsName"]).Replace("'", "''") + "'," + dataTable.Rows[i]["SyncTovShoc"] + "," + Convert.ToInt32(dataTable.Rows[i]["fk_id"] == DBNull.Value ? 0 : dataTable.Rows[i]["fk_id"]) + ")"); ; ;
                        operations.Insert(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                    }
                }
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                LogHelper.Log(LogTarget.SQL, "Error :"+ex.Message);
            }
            
            LogHelper.Log(LogTarget.SQL, "------------------End of prepare reference data for migration--------------------");
        }
    }
}
