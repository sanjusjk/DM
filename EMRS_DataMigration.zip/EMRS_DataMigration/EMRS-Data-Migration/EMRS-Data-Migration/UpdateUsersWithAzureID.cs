﻿using CustomLogs;
using DataAccess;
using GraphWebAPI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EMRS_Data_Migration
{

    public class UpdateUsersWithAzureID
    {
        private DataTable dataTable;
        private readonly IOperations operations;
        private StringBuilder stringBuilder;
        public UpdateUsersWithAzureID()
        {
            operations = new Operations();
        }

        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start Updating Users Table with AzureID--------------------");
            await UpdateAsync();
            LogHelper.Log(LogTarget.SQL, "------------------End Updating Users Table with AzureID--------------------");
        }

        /// <summary>
        /// This method will match users with Azure and update with AzureID(column: emrsuserid) back in the table. 
        /// Pre Requisite: Modify the users table to accomodate emrsuserid.
        /// </summary>
        private async Task UpdateAsync()
        {
            try
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting users from [Users] table with empty Azure id--"));
                stringBuilder = new StringBuilder();

                stringBuilder.Append("Select userid,name,emrsuserid FROM users WHERE  name like '%@%' and isnull(synctoemrs,0)=0 order by name ");
                dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                if (dataTable.Rows.Count > 0)
                {
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                    Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Updating Users with Azure id's--"));
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        try
                        {
                            string User = dataTable.Rows[i].ItemArray[1].ToString();
                            LogHelper.Log(LogTarget.SQL, "\n-- Start sync for "+ User + "--");
                            if (Convert.ToString(dataTable.Rows[i]["emrsuserid"]) == "")
                            {
                                stringBuilder = new StringBuilder();
                                GraphWebAPI.GetAzureUserDetails objGAID = new GetAzureUserDetails();
                                string _azureID =await objGAID.GetAzureUserDetailsAsync(User);
                                if (!string.IsNullOrEmpty(_azureID))
                                {
                                    stringBuilder.Append(String.Format("update users set emrsuserid='{0}' where userid={1}", _azureID, Convert.ToInt32(dataTable.Rows[i].ItemArray[0].ToString())));
                                    operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));

                                    PushUsers pushUsers = new PushUsers();
                                    await pushUsers.PushUsersToEMRS(_azureID);
                                }
                                else
                                {
                                    LogHelper.Log(LogTarget.SQL, "\nNot Found : User not found in Azure.");
                                    //Thread.Sleep(1000);
                                }
                            }
                            else
                            {
                                PushUsers pushUsers = new PushUsers();
                                await pushUsers.PushUsersToEMRS(Convert.ToString(dataTable.Rows[i]["emrsuserid"]));
                            }
                            LogHelper.Log(LogTarget.SQL, "\n-- End sync for " + User + "--");
                            ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\nSQL Exception - \nError:" + ex.Message));
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "SQL Exception - \nError:" + ex.Message));
            }

        }
    }
}
