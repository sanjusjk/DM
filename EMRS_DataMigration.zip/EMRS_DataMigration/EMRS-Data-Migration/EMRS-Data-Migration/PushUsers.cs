﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMRS_Data_Migration
{
    public class PushUsers
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;

        public PushUsers()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
        }

        public async Task<bool> PushUsersToEMRS(string azureid)
        {

            stringBuilder = new StringBuilder();

            stringBuilder.Append("select top 1 c.dataid , case when c.SourceID like 'WHOSTAFF%' then 1");
            stringBuilder.Append(" when c.SourceID like 'CMS-EXPERT%' then 2");
            stringBuilder.Append(" when c.SourceID like 'CMS-EPR%' then 3");
            stringBuilder.Append(" when c.SourceID like 'OLA%' then 4");
            stringBuilder.Append(" when c.SourceID like 'WEBEOC%' then 5 end as priority,");

            stringBuilder.Append("U.name as EmailAddress,C.firstname as FirstName,C.familyname as LastName,C.agency as Agency,C.countrynameEn,C.WHOregion,");
            stringBuilder.Append("C.fullorgpath as OrgPath,");
            stringBuilder.Append("CN.countryEmrsid as CountryId,");
            stringBuilder.Append("RG.regionemrsid as RegionId,");

            stringBuilder.Append("(case when C.fullorgpath like '%/RGO%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Regional Office')");
            stringBuilder.Append("when C.fullorgpath like '%/ACO%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Country Office')");
            stringBuilder.Append("when C.fullorgpath like '%/HQ%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Headquarters')");
            stringBuilder.Append("else (select top 1 emrsid from boardlistitems where parentitemid = 4203 and name in ('(undefined)','') and emrsid <>0) end");
            stringBuilder.Append(") as LocationTypeId,");

            stringBuilder.Append("(case when upper(C.SourceID)='WHOSTAFF' then 1 else 2 end)  as InternalExternalId");
            stringBuilder.Append(" from users U");
            stringBuilder.Append(" inner");
            stringBuilder.Append(" join table_303 C on C.email1 = U.name and C.prevdataid = 0");

            //Join for country
            stringBuilder.Append(" left join (");
            stringBuilder.Append(" select  iso_3_code, c.emrsid as countryEmrsid, c.name from table_300 c1");
            stringBuilder.Append(" left");
            stringBuilder.Append(" join BoardListItems c on c1.adm0_name = c.name");

            stringBuilder.Append(" where c.parentitemid in");
            stringBuilder.Append("            (");
            stringBuilder.Append("                 select boardlistitemsid from BoardListItems where parentitemid in (");
            stringBuilder.Append("                 select boardlistitemsid from BoardListItems where name = 'WHO_regions')");
            stringBuilder.Append("            ) and Prevdataid = 0");
            stringBuilder.Append("  )  CN on UPPER(C.countryIso3Code) = UPPER(CN.iso_3_code)");

            //Join for regions
            stringBuilder.Append("left join(");
            stringBuilder.Append("  select distinct  iso_3_code, cr.emrsid as regionemrsid, cr.name");
            stringBuilder.Append("                 from table_300 r1");
            stringBuilder.Append("                 inner");
            stringBuilder.Append("                 join BoardListItems cr on r1.who_region = cr.name");

            stringBuilder.Append("                 where r1.who_region = cr.name and cr.parentitemid in");
            stringBuilder.Append("                 (select boardlistitemsid from BoardListItems where name = 'WHO_regions')  and iso_3_code is not null");
            stringBuilder.Append("  ) RG on UPPER(C.countryIso3Code) = UPPER(RG.iso_3_code) where U.emrsuserid='" + azureid + "' order by priority asc, c.dataid desc");


            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
            if (dataTable.Rows.Count > 0)
            {
                string token;
                LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " user found--");
                //LogHelper.Log(LogTarget.API, "\n--Push user to EMRS--");
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("UsersAPI"));

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        UsersModel usersModel = new UsersModel();
                        User user = new User()
                        {
                            Agency = Convert.ToString(dataTable.Rows[i]["Agency"]),
                            CountryId = dataTable.Rows[i]["CountryId"] == DBNull.Value ? null : (int?)Convert.ToInt32(dataTable.Rows[i]["CountryId"]),
                            RegionId = dataTable.Rows[i]["RegionId"] == DBNull.Value ? null : (int?)Convert.ToInt32(dataTable.Rows[i]["RegionId"]),
                            UserId = Convert.ToString(azureid),
                            OrgPath = Convert.ToString(dataTable.Rows[i]["OrgPath"]),
                            LocationTypeId = dataTable.Rows[i]["LocationTypeId"] == DBNull.Value ? null : (int?)Convert.ToInt32(dataTable.Rows[i]["LocationTypeId"]),
                            InternalExternalId = Convert.ToInt32(dataTable.Rows[i]["InternalExternalId"]),
                            LastName = Convert.ToString(dataTable.Rows[i]["LastName"]),
                            FirstName = Convert.ToString(dataTable.Rows[i]["FirstName"]),
                            EmailAddress = Convert.ToString(dataTable.Rows[i]["EmailAddress"]).Trim()
                        };

                        usersModel.Users.Add(user);


                        token = await tokenService.GetToken();
                        LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(usersModel));
                        var res = await eMRSAPIs.PushOtherDataToEMRSAsync<UsersModel>(usersModel, System.Configuration.ConfigurationManager.AppSettings.Get("UsersAPI"), token);
                        if (Convert.ToString(res) == "")
                        {
                            return false;
                        }
                        else
                        {
                            operations.Update(LogHelper.Log(LogTarget.SQL, string.Format("Update users set synctoemrs=1 where name='{0}'",Convert.ToString(dataTable.Rows[i]["EmailAddress"]))), ConfigurationManager.AppSettings.Get("vShocDbConnection"));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for -" + Convert.ToString(dataTable.Rows[i]["EmailAddress"]) + "  \nError:" + ex.Message));
                        return false;
                    }
                }
            }

            return true;
        }
    }
    public class UsersModel
    {
        public List<User> Users = new List<User>();
    }
    public class User
    {
        public string UserId { get; set; }
        public string EmailAddress { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string OrgPath { get; set; }
        public int? CountryId { get; set; }
        public int? RegionId { get; set; }
        public int? LocationTypeId { get; set; }
        public int InternalExternalId { get; set; }
        public string Agency { get; set; }
    }
}
