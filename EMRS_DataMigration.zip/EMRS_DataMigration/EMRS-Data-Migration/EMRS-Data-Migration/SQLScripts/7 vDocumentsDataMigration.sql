IF OBJECT_ID('vDocumentsDataMigration', 'V') IS NOT NULL
   DROP VIEW vDocumentsDataMigration;

Go
CREATE VIEW [vDocumentsDataMigration] AS 
select c.incidentName,c.incidentEMRSId,c.hazardName,c.hazardEMRSId,c.documentType,c.documentCategory,c.documentRole,c.attachmentId, f.filename, f.contenttype, f.bin
from ( 
		-- grading 
		select  i.name as incidentName, i.emrsid as incidentEMRSId, t.type as hazardName, h.emrsid as hazardEMRSId,  
			'Grading Memo' as documentType, 
			'Meeting minutes / Debrief / Decisions / Memos' as documentCategory, 
			'Technical & Risk Communications' as documentRole,
			gr.grading_attachment as attachmentId
		from Incidents i
		left join table_280 t on t.systemincidentid = i.incidentid and t.prevdataid = 0
		left join BoardListItems h on t.type = h.name and h.parentitemid = 4933 
		left join table_281 gr on gr.related_incidentid = i.incidentid and gr.grading_attachment is not null and gr.prevdataid = 0
		where gr.grading_attachment is not null
		union
		-- risk assessment
		select  i.name as incidentName, i.emrsid as incidentEMRSId, t.type as hazardName, h.emrsid as hazardEMRSId, 
			'Rapid Risk Assessment (RRA)' as documentType,
			'Analysis and Research' as documentCategory,
			'Technical & Risk Communications' as documentRole,
			ra.ra_attachment as attachmentId
		from Incidents i
		left join table_280 t on t.systemincidentid = i.incidentid and t.prevdataid = 0
		left join BoardListItems h on t.type = h.name and h.parentitemid = 4933 
		left join table_281 ra on ra.related_incidentid = i.incidentid and ra.ra_attachment is not null and ra.prevdataid = 0
		where ra.ra_attachment is not null 
		) as c
        left join Files f on c.attachmentId = f.id
