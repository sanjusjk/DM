﻿
--************************Creation Script *******************************
 --  Add emrsuserid (guid) column into USERS table (AzureID)  --NOColumn 
IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'emrsuserid')
Begin
        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.users_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.users_backup_referencedata

		SELECT * INTO users_backup_referencedata FROM users
		
		alter table users add emrsuserid nvarchar(max) 
        alter table users add synctoemrs bit default 0
		Print 'CREATED : emrsuserid is created in users'
End
else 
   Print  'NOT CREATED - emrsuserid already exists users'

-----------------------------------------------------------------------------------------

--Add emrsid (guid) column into incident table (table_280)   -- yes column
IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Incidents' AND COLUMN_NAME = 'emrsid')
Begin
        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.Incidents_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.Incidents_backup_referencedata

		SELECT * INTO Incidents_backup_referencedata FROM Incidents

		Alter table Incidents add emrsid nvarchar(max) 
		Print 'CREATED : emrsid is created in table_280'

End
else 
        Print  'NOT CREATED - emrsid already exists in table_280'

-----------------------------------------------------------------------------------------

--Add emrsid (int) column into BoardListItems table 
IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'BoardListItems' AND COLUMN_NAME = 'emrsid')  -- yes column
Begin

        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.BoardListItems_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.BoardListItems_backup_referencedata

		SELECT * INTO BoardListItems_backup_referencedata FROM BoardListItems

		Alter table BoardListItems add emrsid int default 0 
		Print 'CREATED : emrsid is created in BoardListItems'
End
else
     Print  'NOT CREATED - emrsid already exists in BoardListItems'
	 
-----------------------------------------------------------------------------------------

--Add emrsid (int) column  into function / Role related tables (table_264,table_265)
IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS   
WHERE TABLE_NAME = 'table_264' AND COLUMN_NAME = 'emrsid')      -- yes column
Begin

        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.table_264_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.table_264_backup_referencedata

		SELECT * INTO table_264_backup_referencedata FROM table_264

		Alter table table_264 add emrsid int default 0 
		Print 'CREATED : emrsid is created in table_264'
End
else 
      print 'NOT CREATED - emrsid already exists in table_264'
	  
-----------------------------------------------------------------------------------------

IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'table_265' AND COLUMN_NAME = 'emrsid')  -- yes column
Begin

        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.table_265_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.table_265_backup_referencedata

		SELECT * INTO table_265_backup_referencedata FROM table_265

		Alter table table_265 add emrsid int default 0 
		Print 'CREATED : emrsid is created in table_265'
End
else 
       Print 'NOT CREATED - emrsid already exists in table_265'
	   
-----------------------------------------------------------------------------------------


--Add emrsid (int) column into Positions table
IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Positions' AND COLUMN_NAME = 'emrsid')  -- yes column
Begin

        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.Positions_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.Positions_backup_referencedata

		SELECT * INTO Positions_backup_referencedata FROM Positions

		Alter table Positions add emrsid int default 0 
		Print 'CREATED : emrsid is created in Positions'

End
else 
    Print 'NOT CREATED - emrsid already exists in Positions'
----------------------------------------------------------------------------------------

IF NOT EXISTS (SELECT '1' FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'table_306' AND COLUMN_NAME = 'emrsid')
Begin
        -- Delete backup if already exist --
        IF OBJECT_ID('dbo.table_306_backup_referencedata', 'U') IS NOT NULL 
             DROP TABLE dbo.table_306_backup_referencedata

		SELECT * INTO table_306_backup_referencedata FROM table_306

		Alter table table_306 add emrsid nvarchar(max) null
		Print 'CREATED : emrsid is created in table_306'

End
else 
        Print  'NOT CREATED - emrsid already exists in table_306'​

update Incidents set name = 'Somalia AWD / Cholera 2017 - 2019 (bis)' where incidentid = 381

update users set emrsuserid=null,synctoemrs=0
update Incidents set emrsid=null
update BoardListItems set emrsid=0
update table_264 set emrsid=0
update table_265 set emrsid=0
update Positions set emrsid=0
update table_306 set emrsid=null

--------------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('usp_EMRS_GetAssignmentData', 'P') IS NOT NULL
DROP PROC usp_EMRS_GetAssignmentData
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[usp_EMRS_GetAssignmentData] 
	-- Add the parameters for the stored procedure here
	@dataid int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	  select
                D.dataid as AssignmentLocalId,
                I.emrsid as OccurrenceId,

                (case when D.deploymenttype= 'Local Assignment' then 'assignment'
                when D.deploymenttype= 'Deployment' then 'deployment'
                when D.deploymenttype= 'Recipient of information' then 'recipientOfInformation'
                else D.deploymenttype end) as AssignmentType,

                D.assignment_start_date as StartDate,
                D.assignment_end_date as EndDate,

                (case when D.deployee_status='Awaiting Approval' then 'awaitingapproval'
				 when D.deployee_status='In Process' then 'inprocess' else D.deployee_status end
				)as AssignmentStatus,

                (
                   select emrsid from dbo.table_264 where  upper(level1name)=upper(D.assigned_function) and fk_table_263 in
                   (select isnull(dataid,0) from dbo.table_263 where listname = 'AssignmentsFunction_Roles' and prevdataid=0)
                ) as AssignmentFunctionId,

                (
                 select emrsid from dbo.table_265 where upper(level2name)=upper(D.assigned_role) and
                 fk_table_264 in (
                                   select dataid from dbo.table_264 where upper(level1name)=upper(D.assigned_function) and fk_table_263 in
                                   (select isnull(dataid,0) from dbo.table_263 where listname = 'AssignmentsFunction_Roles' and prevdataid=0))
                )as AssignmentRoleId,

                ( select emrsid from boardlistitems where name =L.locationtype and
                  parentitemid in (select boardlistitemsid from boardlistitems
                  where name like '%deployment location type%' and parentitemid=0)
                ) as LocationTypeId,

                (
                select emrsid from boardlistitems where upper(name)=UPPER(L.country) and parentitemid in (
                select boardlistitemsid from boardlistitems where
                parentitemid in (select boardlistitemsid from boardlistitems where name like '%who_regions%' and parentitemid=0))
                ) as CountryId,

                (
                select emrsid from boardlistitems where boardlistitemsid in(
                select parentitemid from boardlistitems where upper(name)=UPPER(L.country) and  parentitemid in (
                select boardlistitemsid from boardlistitems where
                parentitemid in (select boardlistitemsid from boardlistitems where name like '%who_regions%' and parentitemid=0)))
                ) as RegionId,
				(select top 1 emrsuserid from Users where name=C.email1 and synctoemrs=1) as [EmrsUser],
				D.emrsid
                from table_306 D
                Left Join Incidents I on I.incidentid=D.incidentid
                Left join table_304 L on L.dataid=D.fk_table_304
				Left join table_303 C on C.dataid=D.fk_table_303
                where D.prevdataid=0 and D.dataid=@dataid order by D.dataid desc
END



-----------------------------------------------------------------------------------------------------------------------------------------------
Go
IF OBJECT_ID('usp_EMRS_GetContactData', 'P') IS NOT NULL
DROP PROC [usp_EMRS_GetContactData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_EMRS_GetContactData] 
	-- Add the parameters for the stored procedure here
	@dataid int, --contact dataid from table_303
	@email nvarchar(max), --contact emailid from table_303
	@insert bit=0 -- need to insert in Users table ?
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if(@insert=1)
	Begin
	   if((select count(userid) from users where  rtrim(ltrim(name)) like @email)=0)
	   begin
	      INSERT [dbo].[Users] (
		   Name,
		   Password,
		   Primaryemail,
		   Multipleuser,
		   Administrator,
		   Deletable,
		   Failedattempts,
		   Accountlocked,
		   Mustchangepwd,
		   Salt,
		   Dualcommit,
		   Langlcid,
		   Formatlcid,
		   Timezoneoverride,
		   Timezone,
		   Daylight,
		   comments,
		   realname,
		   officephoneisdefault,
		   attachmentid,
		   overrideorglocale,
		   disableuserupdate,
		   allowinactivityexpiration,
		   accounttype,
		   passwordset
		   )
	      select
		  email1, --Name
		  '',-- Password
		  email1,--Primaryemail
		  0, --Multipleuser
		  0,--Administrator
		  1,--Deletable
		  0,--Failedattempts
		  0,--Accountlocked
		  0,-- Mustchangepwd,
		  '',--Salt
		  0,--Dualcommit
		  0,--Langlcid
		  0,--Formatlcid
		  0,--Timezoneoverride
		  60,--Timezone
		  0,--Daylight
		  ' ',--comments
		  familyname,--realname
		  1,--officephoneisdefault
		  0,--attachmentid
		  0,--overrideorglocale
		  0,--disableuserupdate
		  1,--allowinactivityexpiration
		  0,--accounttype
		  getdate()--passwordset
          from table_303 where dataid=@dataid and prevdataid=0
	   end
	End

	select top 1 c.dataid , case when c.SourceID like 'WHOSTAFF%' then 1
             when c.SourceID like 'CMS-EXPERT%' then 2
             when c.SourceID like 'CMS-EPR%' then 3
             when c.SourceID like 'OLA%' then 4
             when c.SourceID like 'WEBEOC%' then 5 end as priority,

            U.name as EmailAddress,C.firstname as FirstName,C.familyname as LastName,C.agency as Agency,C.countrynameEn,C.WHOregion,
            C.fullorgpath as OrgPath,
            CN.countryEmrsid as CountryId,
            RG.regionemrsid as RegionId,

            (case when C.fullorgpath like '%/RGO%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Regional Office')
            when C.fullorgpath like '%/ACO%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Country Office')
            when C.fullorgpath like '%/HQ%' then(select emrsid from boardlistitems where parentitemid = 4203 and name = 'Headquarters')
            else (select top 1 emrsid from boardlistitems where parentitemid = 4203 and name in ('(undefined)','') and emrsid <>0) end
            ) as LocationTypeId,

            (case when upper(C.SourceID)='WHOSTAFF' then 1 else 2 end)  as InternalExternalId
             from users U
             inner
             join table_303 C on C.email1 = U.name and C.prevdataid = 0

            --Join for country
             left join (
             select  iso_3_code, c.emrsid as countryEmrsid, c.name from table_300 c1
             left
             join BoardListItems c on c1.adm0_name = c.name

             where c.parentitemid in
                        (
                             select boardlistitemsid from BoardListItems where parentitemid in (
                             select boardlistitemsid from BoardListItems where name = 'WHO_regions')
                        ) and Prevdataid = 0
              )  CN on UPPER(C.countryIso3Code) = UPPER(CN.iso_3_code)

            --Join for regions
            left join(
              select distinct  iso_3_code, cr.emrsid as regionemrsid, cr.name
                             from table_300 r1
                             inner
                             join BoardListItems cr on r1.who_region = cr.name

                             where r1.who_region = cr.name and cr.parentitemid in
                             (select boardlistitemsid from BoardListItems where name = 'WHO_regions')  and iso_3_code is not null
              ) RG on UPPER(C.countryIso3Code) = UPPER(RG.iso_3_code) where U.name=@email order by priority asc, c.dataid desc

END
GO
