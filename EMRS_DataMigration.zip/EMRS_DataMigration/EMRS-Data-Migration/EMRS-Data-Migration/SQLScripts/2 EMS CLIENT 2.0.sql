/** START CODE BLOCK FOR CREATE of VIEW, TABLE, STORE PROCEDURE OR FUNCTION **/

/* START EMRS-1014 */
BEGIN TRAN
IF EXISTS (SELECT * FROM sys. objects WHERE object_id = OBJECT_ID('dbo.vw_EMRSDocumentMetaData') AND type = 'V')
DROP VIEW [dbo].[vw_EMRSDocumentMetaData];
GO
CREATE VIEW [dbo].[vw_EMRSDocumentMetaData]
AS
WITH Document_Category as(
SELECT 1 categoryId,'Event Creation' categoryName, null document_Type, 'Other' document_Category, 'Event management' document_Role UNION
SELECT 2,'General Information', null, 'Other', 'Event management' UNION
SELECT 3,'Verification',null, 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 4,'Risk Assessment',null, 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 5,'Situation Report','Internal Situation Reports', 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 6,'Event Information Site Output',null, 'Publications & Reports', 'Technical & Risk Communications' UNION
SELECT 7,'GOARN Output','GOARN', 'Correspondence', 'Resource Mobilization' UNION
SELECT 8,'Epidemiology',null, 'Other', 'Epidemiology' UNION
SELECT 9,'Initial Source',null,  'Other', 'Event management' UNION
SELECT 10,'Deployment',null, 'Other', 'Resource Mobilization' UNION
SELECT 11,'Daily Agenda',null, 'Meeting minutes / Debrief / Decisions / Memos', 'Leadership' UNION
SELECT 12,'Operations',null, 'Other', 'Event management' UNION
SELECT 13,'Presentation',null, 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 14,'Designation',null, 'Analysis and Research', 'Technical & Risk Communications'  UNION  
SELECT 15,'Laboratory','Laboratory tests', 'Analysis and Research', 'Laboratory' UNION
SELECT 23,'Rapid Risk Assessment','Rapid Risk Assessment (RRA)', 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 24,'Summary Bullet',null, 'Analysis and Research', 'Technical & Risk Communications' UNION
SELECT 25,'Information Products',null, 'Publications & Reports', 'Technical & Risk Communications')
SELECT EF.filename, 
	   '{fileURL}/' + EF.fileName FileURL, 
	   ISNULL(FTL.fileTypeName,'') FileType,E.eventDisplayID event_displayName,USM.sourceTypeId source_information, 
	   CASE WHEN EF.isMapFlag = 'Y' THEN 'GIS' ELSE DC.document_Role END document_Role,
	   CASE WHEN (CASE WHEN CHARINDEX('.',fileName) > 0 THEN  reverse(left(reverse(fileName),charindex('.',reverse(fileName))-1)) ELSE '' END) = 'msg' THEN 'Correspondence' ELSE CASE WHEN EF.isMapFlag = 'Y' THEN 'Other' ELSE DC.document_Category END END document_Category, 
	   CASE WHEN EF.isMapFlag = 'Y' THEN 'Maps' ELSE DC.document_Type END document_Type, confidentialFlag confidential,e.emrsID Event_EMRSId , LU.emrsID language,H.emrsId Hazard_EMRSId, S.emrsId Syndrome_EMRSId, D.emrsId Discon_EMRSId, A.emrsID Aetiology_EMRSId, R.emrsID Region_EMRSId, c.emrsID Country_EMRSId, SV.emrsID Sovereign_EMRSId  
FROM eventFile EF
LEFT JOIN dbo.updateFile UF
	ON UF.fileID = EF.fileID
LEFT JOIN dbo.eventUpdate_XWalk EUX
	ON EUX.updateMasterID = UF.updateMasterID
LEFT JOIN dbo.event E
	ON E.eventID = EUX.eventID
LEFT JOIN dbo.hazard H
	ON H.hazardId = E.hazardId
LEFT JOIN dbo.syndrome S
	ON S.syndromeId = E.syndromeId
LEFT JOIN dbo.disCon D
	ON D.disConID = E.disConID
LEFT JOIN aetiology_Lookup A
	ON A.aetiologyId = E.aetiologyId
INNER JOIN region_Lookup R
	ON R.regionId = E.regionId
LEFT JOIN country_Lookup C
	ON C.countryID = E.countryID
LEFT JOIN country_Lookup SV
	ON SV.countryID = E.sovereignID
LEFT JOIN category_Lookup CL
	ON CL.categoryId = EF.categoryId
LEFT JOIN fileType_Lookup FTL
	ON FTL.fileTypeId = EF.fileTypeId
LEFT JOIN language_Lookup LU
	ON LU.languageId = EF.languageID
LEFT JOIN (SELECT um.updateMasterID,um.sourceId,categoryId,confidentialFlag,sourceTypeId FROM updateMaster  um
	INNER JOIN updateSource un
		ON un.sourceID = um.sourceID) USM
	ON USM.updateMasterId = UF.updateMasterID
LEFT JOIN Document_Category DC
	ON DC.CategoryId = USM.categoryID
GO
/* END EMRS-1014 */

/** END CODE BLOCK FOR CREATE of VIEW, TABLE, STORE PROCEDURE OR FUNCTION **/

/* START EMRS-786 */
IF EXISTS (
       SELECT type_desc, type
       FROM sys.procedures WITH(NOLOCK)
       WHERE NAME = 'sp_GetCountryEMRSId'
           AND type = 'P'
     )
DROP PROCEDURE [dbo].[sp_GetCountryEMRSId];
GO
CREATE PROCEDURE [dbo].[sp_GetCountryEMRSId]
(
	@countryID INT
)

AS
DECLARE @emrsID AS INT;

SELECT @emrsID = emrsID FROM country_Lookup WHERE countryID = @countryId

IF @emrsID IS NOT NULL
BEGIN
	SELECT @countryID,@emrsID
END
GO
/* END EMRS-786 */


BEGIN TRANSACTION

BEGIN TRY
	/* START EMRS-786 */
	PRINT('EXECUTING EMRS-786')
	IF COL_LENGTH('event','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[event] ADD emrsID varchar(50) NULL;
	END
	ELSE
	BEGIN
		PRINT 'SKIPPING : emrsId already exist in [event] table'
	END
	
	IF COL_LENGTH('eventGroup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[eventGroup] ADD emrsID varchar(50) NULL;
	END
	ELSE
	BEGIN
		PRINT 'SKIPPING : emrsId already exist in [eventGroup] table'
	END	
	/* END EMRS-786 */

	PRINT('EXECUTING EMRS-1010')
	IF COL_LENGTH('eventadmin','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].eventAdmin ADD emrsID varchar(50) NULL;
	END
	ELSE
	BEGIN
		PRINT 'SKIPPING : emrsId already exist in [eventAdmin] table'
	END

	ROLLBACK TRANSACTION
END TRY
BEGIN CATCH
	PRINT 'ERROR' + ERROR_MESSAGE()
	ROLLBACK TRANSACTION
END CATCH