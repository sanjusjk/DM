/*
EMS API 2.0
*/

BEGIN TRANSACTION
BEGIN TRY
	--EMRS-688
	PRINT('Executing EMRS-688')
	IF COL_LENGTH('hazard','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[hazard] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-688. emrsId already Exist in Hazard table'
	END

	--EMRS-689
	PRINT('Executing EMRS-689')
	IF COL_LENGTH('language_Lookup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[language_Lookup] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-689. emrsId already Exist in language_Lookup table'
	END

	--EMRS-690
	PRINT('Executing EMRS-690')
	IF COL_LENGTH('region_Lookup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[region_Lookup] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-690. emrsId already Exist in [region_Lookup] table'
	END

	--EMRS-748
	PRINT('Executing EMRS-748')
	IF COL_LENGTH('syndrome','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[syndrome] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-748. emrsId already Exist in [syndrome] table'
	END

	--EMRS-749
	PRINT('Executing EMRS-749')
	IF COL_LENGTH('disCon','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[disCon] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-749. emrsId already Exist in [disCon] table'
	END

	--EMRS-750
	PRINT('Executing EMRS-750')
	IF COL_LENGTH('country_Lookup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[country_Lookup] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-750. emrsId already Exist in [country_Lookup] table'
	END

	--EMRS-778
	PRINT('Executing EMRS-778')
	IF COL_LENGTH('sourceType_Lookup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[sourceType_Lookup] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-778. emrsId already Exist in [sourceType_Lookup] table'
	END

	--EMRS-809
	PRINT('Executing EMRS-809')
	IF COL_LENGTH('aetiology_Lookup','emrsId') IS NULL
	BEGIN
		ALTER TABLE [dbo].[aetiology_Lookup] ADD emrsID INT NULL;
	END
	ELSE
	BEGIN
		PRINT 'Skipping EMRS-809. emrsId already Exist in [aetiology_Lookup] table'
	END
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
	PRINT 'ERROR : ' + ERROR_MESSAGE()
	ROLLBACK TRANSACTION;
END CATCH