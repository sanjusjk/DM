IF OBJECT_ID('vSharePointDataMigration', 'V') IS NOT NULL
   DROP VIEW vSharePointDataMigration;

Go
CREATE VIEW [vSharePointDataMigration] AS 
select  i.name as indidentName, i.emrsid as incidentEMRSId, t.type as hazardName, h.emrsid as hazardEMRSId, t.sharepoint_url
from Incidents i
left join table_280 t on t.systemincidentid = i.incidentid and t.prevdataid = 0
left join BoardListItems h on t.type = h.name and h.parentitemid = 4933
where t.sharepoint_url is not null and t.sharepoint_url <> ''
