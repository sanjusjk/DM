
delete from eventAlertDisCon_XWalk where disConID = 356
delete from disCon where disConID = 356 
update discon set disconName = '(obsolete)' where disconId = 0
update syndrome set syndromeName = '(obsolete)' where syndromeID = 0
update sourceType_Lookup set sourceTypeName = sourceTypeName + ' (old)' where sourceTypeID in (139, 159)

SELECT * INTO event_backup_<date> FROM event
SELECT * INTO aetiology_Lookup_backup_<date> FROM aetiology_Lookup


-- make backup Of table aetiology_Lookup
update event set aetiologyID = 736 where aetiologyID = 737
update event set aetiologyID_Initial = 736 where aetiologyID_Initial = 737
delete from aetiology_Lookup where aetiologyID = 737
update event set aetiologyID = 714 where aetiologyID = 716
update event set aetiologyID_Initial = 714 where aetiologyID_Initial = 716
delete from aetiology_Lookup where aetiologyID = 716
update event set aetiologyID = 782 where aetiologyID = 784
update event set aetiologyID_Initial = 782 where aetiologyID_Initial = 784
delete from aetiology_Lookup where aetiologyID = 784
update event set aetiologyID = 785 where aetiologyID = 788
update event set aetiologyID_Initial = 785 where aetiologyID_Initial = 788
delete from aetiology_Lookup where aetiologyID = 788
update event set aetiologyID = 943 where aetiologyID = 944
update event set aetiologyID_Initial = 943 where aetiologyID_Initial = 944
delete from aetiology_Lookup where aetiologyID = 944
update event set aetiologyID = 974 where aetiologyID = 976
update event set aetiologyID_Initial = 974 where aetiologyID_Initial = 976
delete from aetiology_Lookup where aetiologyID = 976
update event set aetiologyID = 978 where aetiologyID = 980
update event set aetiologyID_Initial = 978 where aetiologyID_Initial = 980
delete from aetiology_Lookup where aetiologyID = 980
update event set aetiologyID = 1126 where aetiologyID = 1129
update event set aetiologyID_Initial = 1126 where aetiologyID_Initial = 1129
delete from aetiology_Lookup where aetiologyID = 1129
update event set aetiologyID = 1126 where aetiologyID = 1570
update event set aetiologyID_Initial = 1126 where aetiologyID_Initial = 1570
delete from aetiology_Lookup where aetiologyID = 1570
update event set aetiologyID = 1447 where aetiologyID = 1448
update event set aetiologyID_Initial = 1447 where aetiologyID_Initial = 1448
delete from aetiology_Lookup where aetiologyID = 1448
update event set aetiologyID = 396 where aetiologyID = 1538
update event set aetiologyID_Initial = 396 where aetiologyID_Initial = 1538
delete from aetiology_Lookup where aetiologyID = 1538
update event set aetiologyID = 473 where aetiologyID = 1550
update event set aetiologyID_Initial = 473 where aetiologyID_Initial = 1550
delete from aetiology_Lookup where aetiologyID = 1550
update event set aetiologyID = 1437 where aetiologyID = 1582
update event set aetiologyID_Initial = 1437 where aetiologyID_Initial = 1582
delete from aetiology_Lookup where aetiologyID = 1582
update event set aetiologyID = 1589 where aetiologyID = 1591
update event set aetiologyID_Initial = 1589 where aetiologyID_Initial = 1591
delete from aetiology_Lookup where aetiologyID = 1591
update event set aetiologyID = 1614 where aetiologyID = 1630
update event set aetiologyID_Initial = 1614 where aetiologyID_Initial = 1630
delete from aetiology_Lookup where aetiologyID = 1630
update event set aetiologyID = 174 where aetiologyID = 1650
update event set aetiologyID_Initial = 174 where aetiologyID_Initial = 1650
delete from aetiology_Lookup where aetiologyID = 1650
update event set aetiologyID = 275 where aetiologyID = 1680
update event set aetiologyID_Initial = 275 where aetiologyID_Initial = 1680
delete from aetiology_Lookup where aetiologyID = 1680
update event set aetiologyID = 743 where aetiologyID = 1687
update event set aetiologyID_Initial = 743 where aetiologyID_Initial = 1687
delete from aetiology_Lookup where aetiologyID = 1687
update event set aetiologyID = 1703 where aetiologyID = 1704
update event set aetiologyID_Initial = 1703 where aetiologyID_Initial = 1704
delete from aetiology_Lookup where aetiologyID = 1704
update event set aetiologyID = 1260 where aetiologyID = 1713
update event set aetiologyID_Initial = 1260 where aetiologyID_Initial = 1713
delete from aetiology_Lookup where aetiologyID = 1713
update event set aetiologyID = 1710 where aetiologyID = 1746
update event set aetiologyID_Initial = 1710 where aetiologyID_Initial = 1746
delete from aetiology_Lookup where aetiologyID = 1746
update event set aetiologyID = 1191 where aetiologyID = 1772
update event set aetiologyID_Initial = 1191 where aetiologyID_Initial = 1772
delete from aetiology_Lookup where aetiologyID = 1772
update event set aetiologyID = 1546 where aetiologyID = 1805
update event set aetiologyID_Initial = 1546 where aetiologyID_Initial = 1805
delete from aetiology_Lookup where aetiologyID = 1805
update event set aetiologyID = 1546 where aetiologyID = 1825
update event set aetiologyID_Initial = 1546 where aetiologyID_Initial = 1825
delete from aetiology_Lookup where aetiologyID = 1825
update event set aetiologyID = 1509 where aetiologyID = 1809
update event set aetiologyID_Initial = 1509 where aetiologyID_Initial = 1809
delete from aetiology_Lookup where aetiologyID = 1809
update event set aetiologyID = 1780 where aetiologyID = 2029
update event set aetiologyID_Initial = 1780 where aetiologyID_Initial = 2029
delete from aetiology_Lookup where aetiologyID = 2029
update event set aetiologyID = 364 where aetiologyID = 1848
update event set aetiologyID_Initial = 364 where aetiologyID_Initial = 1848
delete from aetiology_Lookup where aetiologyID = 1848
update event set aetiologyID = 1673 where aetiologyID = 2064
update event set aetiologyID_Initial = 1673 where aetiologyID_Initial = 2064
delete from aetiology_Lookup where aetiologyID = 2064
update event set aetiologyID = 572 where aetiologyID = 2065
update event set aetiologyID_Initial = 572 where aetiologyID_Initial = 2065
delete from aetiology_Lookup where aetiologyID = 2065
update event set aetiologyID = 745 where aetiologyID = 1852
update event set aetiologyID_Initial = 745 where aetiologyID_Initial = 1852
delete from aetiology_Lookup where aetiologyID = 1852
update event set aetiologyID = 793 where aetiologyID = 1894
update event set aetiologyID_Initial = 793 where aetiologyID_Initial = 1894
delete from aetiology_Lookup where aetiologyID = 1894
update event set aetiologyID = 1982 where aetiologyID = 1996
update event set aetiologyID_Initial = 1982 where aetiologyID_Initial = 1996
delete from aetiology_Lookup where aetiologyID = 1996
update event set aetiologyID = 1274 where aetiologyID = 1915
update event set aetiologyID_Initial = 1274 where aetiologyID_Initial = 1915
delete from aetiology_Lookup where aetiologyID = 1915
update event set aetiologyID = 1300 where aetiologyID = 1826
update event set aetiologyID_Initial = 1300 where aetiologyID_Initial = 1826
delete from aetiology_Lookup where aetiologyID = 1826
update event set aetiologyID = 1991 where aetiologyID = 1992
update event set aetiologyID_Initial = 1991 where aetiologyID_Initial = 1992
delete from aetiology_Lookup where aetiologyID = 1992


update country_Lookup set countryCode3 = 'BQX' where countryCode3 = 'BQ1'
delete from country_Lookup where countryName  = 'CYPRUS' and isActiveFlag = 0


---Reset emrsid---
update hazard set emrsid=null
update language_Lookup set emrsid=null
update region_Lookup set emrsid=null
update syndrome set emrsid=null
update disCon set emrsid=null
update country_Lookup set emrsid=null
update sourceType_Lookup set emrsid=null
update aetiology_Lookup set emrsid=null
update eventAdmin set emrsid=null
update eventlink set emrsid=null
update event set emrsid=null