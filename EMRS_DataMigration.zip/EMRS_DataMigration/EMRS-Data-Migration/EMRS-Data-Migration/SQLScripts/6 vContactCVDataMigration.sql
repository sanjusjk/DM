IF OBJECT_ID('vContactCVDataMigration', 'V') IS NOT NULL
   DROP VIEW vContactCVDataMigration;

Go
CREATE VIEW [vContactCVDataMigration] AS 

select c.contactGUID,c.firstname, c.familyname,c.attachmentId,c.documentType,c.documentCategory,c.documentRole, f.filename, f.contenttype, f.bin
  
  from ( 

        -- CV
		select contactGUID, c.firstname, c.familyname, c.cvattachmentid as attachmentId,
			'Curriculum Vitae (CV)' as documentType,
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.cvattachmentid is not null and c.cvattachmentid <> 0
		union
		-- ssafe training
		select contactGUID, c.firstname, c.familyname,c.safetraining_cert_attachmentid as attachmentId,
			'Training certificate' as documentType,
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.safetraining_cert_attachmentid is not null and c.safetraining_cert_attachmentid <> 0
		-- bsafe training
		union
		select contactGUID,  c.firstname, c.familyname,c.bsafe_cert_attachmentid as attachmentId,
			'Training certificate' as documentType,
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.bsafe_cert_attachmentid is not null and c.bsafe_cert_attachmentid <> 0
		-- education certificate
		union
		select contactGUID, c.firstname, c.familyname,c.educ_cert_attachmentid as attachmentId,
			'Education certificate' as documentType, 
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.educ_cert_attachmentid is not null and c.educ_cert_attachmentid <> 0
		-- advanced sec
		union
		select contactGUID, c.firstname, c.familyname,c.advancedsec_cert_attachmentid as attachmentId,
			'Training certificate' as documentType, 
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.advancedsec_cert_attachmentid is not null and c.advancedsec_cert_attachmentid <> 0
		-- basic sec
		union
		select contactGUID, c.firstname, c.familyname,c.basicsec_cert_attachment as attachmentId,
			'Training certificate' as documentType,
			'Other' as documentCategory,
			'HR' as documentRole
		from table_303 c
		where c.prevdataid = 0 and  c.basicsec_cert_attachment is not null and c.basicsec_cert_attachment <> 0 
		
		) as c
        
		left join Files f on c.attachmentId = f.id