﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using EMRSAPI;
using EMRSAPI.Model;
using EMRSAPI.RefDataResponse;

namespace EMRS_Data_Migration
{
    class Program
    {
        static async Task Main(string[] args)
        {
            //to increase input lenght (Do not remove this code)
            byte[] inputBuffer = new byte[4096];
            Stream inputStream = Console.OpenStandardInput(inputBuffer.Length);
            Console.SetIn(new StreamReader(inputStream, Console.InputEncoding, false, inputBuffer.Length));

            //delete the log file if exist (Do not remove this code)
            if (System.IO.File.Exists(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\APILog.txt"))
            {
                System.IO.File.Delete(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\APILog.txt");
            }
            if (System.IO.File.Exists(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\SQLLog.txt"))
            {
                System.IO.File.Delete(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\SQLLog.txt");
            }
            //Log file location
            Console.WriteLine("Log File Location" + Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));

            //Open log file folder
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                Arguments = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                FileName = "explorer.exe"
            };
            Process.Start(startInfo);

            Console.WriteLine("\nPlease type Yes or No for upcoming questions -");

            Console.WriteLine("Did you execute the sql script to create emrsid columns in Vshoc & EMS database?");
            if (Console.ReadLine().ToUpper() != "YES")
            {
                return;
            }
            Console.WriteLine("\nDid you execute the sql script to create and insert record in EMRSDataMigration table?");
            if (Console.ReadLine().ToUpper() != "YES")
            {
                return;
            }
            Console.WriteLine("\nDid you fetch azureid for users and imported into database table?");
            if (Console.ReadLine().ToUpper() != "YES")
            {
                return;
            }

            Console.WriteLine("\n 1. Reference Data Migration.\n 2. Emergency Data Migration.\n 3. Events Data Migration.\n 4. Events Group Data Migration." +
                "\n 5. EventAdmin Data Migration.\n 6. Assignments Data Migration.\n 7. Users Data Migration.\n 8. All Data Migration");

            Console.WriteLine("\nSelect Module To Run : ");
            string Operation = Console.ReadLine();

            switch (Operation)
            {
                case "1":
                    {
                        await PushReferenceData();
                        break;
                    }
                case "2":
                    {
                        await PushEmergencyData();
                        break;
                    }
                case "3":
                    {
                        await PushEventsData();
                        break;
                    }
                case "4":
                    {
                        await PushEventsGroupData();
                        break;
                    }
                case "5":
                    {
                        await PushEventsAdminData();
                        break;
                    }
                case "6":
                    {
                        await PushAssignmentData();
                        break;
                    }
                case "7":
                    {
                        await PushContactsData();
                        break;
                    }
                case "8":
                    {
                        await PushReferenceData();
                        await PushEmergencyData();
                        await PushEventsData();
                        await PushEventsGroupData();
                        await PushContactsData();
                        await PushEventsAdminData();
                        await PushAssignmentData();
                        break;
                    }
            }

            Console.WriteLine("\nPress any key for exit");
            Console.ReadKey();

        }
        static async Task PushReferenceData()
        {
            #region Reference data migration
            //Add ems ref data into EMRSDataMigration table in vShoc database
            AddRefData addRefData = new AddRefData();
            addRefData.StartProcess();//comment this line if you dont want to execute

            //Push reference data to emrs 
            PushReferenceData pushReferenceData = new PushReferenceData();
            await pushReferenceData.StartProcessAsync();//comment this line if you dont want to execute

            #endregion
        }
        static async Task PushEmergencyData()
        {
            #region Push EMS2 Emergency
            PushEmergencies pushEmergencies = new PushEmergencies();
            await pushEmergencies.StartProcessAsync();//comment this line if you dont want to execute
            #endregion
        }
        static async Task PushEventsData()
        {
            #region PushEvents
            PushEvents pushEvents = new PushEvents();
            await pushEvents.StartProcessAsync();
            #endregion
        }
        static async Task PushEventsGroupData()
        {
            #region Push EventGroups
            PushEventGroups pushEventGroups = new PushEventGroups();
            await pushEventGroups.StartProcessAsync();
            #endregion
        }

        static async Task PushEventsAdminData()
        {
            #region Push EventAdmins
            PushEventAdmins pushEventAdmins = new PushEventAdmins();
            await pushEventAdmins.StartProcessAsync();
            #endregion
        }
        static async Task PushContactsData()
        {
            #region Push ContactsData
            // Insert records which has AzureID into Users table from table_303
            PushContactDataToUsers pushContact = new PushContactDataToUsers();
            pushContact.StartProcess();

            // Update Users Table with AzureID using Graph API
            UpdateUsersWithAzureID updateContact = new UpdateUsersWithAzureID();
            await updateContact.StartProcessAsync();
            #endregion
        }

        static async Task PushAssignmentData()
        {
            #region Push EventAdmins
            PushAssignments pushAssignments = new PushAssignments();
            await pushAssignments.StartProcessAsync();
            #endregion
        }
    }
   
}
