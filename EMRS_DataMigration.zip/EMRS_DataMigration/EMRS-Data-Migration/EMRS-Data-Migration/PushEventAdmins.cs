﻿using CustomLogs;
using DataAccess;
using EMRSAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMRSAPI.AssignmentResponse;
using GraphWebAPI;

namespace EMRS_Data_Migration
{
   public class PushEventAdmins
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMS2ClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMS2ClientSecret"].ToString();
        private static readonly string EMS2Scope = ConfigurationManager.AppSettings["EMS2Scope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["APITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        private StringBuilder stringBuilder;
        private DataTable dataTable;
        private readonly IOperations operations;
        private EMRSAPI.Interface.IEMRSAPIs eMRSAPIs;
        

        public PushEventAdmins()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
            operations = new Operations();
            eMRSAPIs = new EMRSAPIServices();
            
        }

        public async Task StartProcessAsync()
        {
            LogHelper.Log(LogTarget.SQL, "------------------Start EventAdmin migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------Start EventAdmin data migration--------------------");


            await PushEventAdminsAsync();



            LogHelper.Log(LogTarget.SQL, "------------------End EventAdmin migration--------------------");
            LogHelper.Log(LogTarget.API, "------------------End EventAdmin data migration--------------------");
        }

        private async Task PushEventAdminsAsync()
        {
            Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Selecting EventAdmin from EMS--"));
            stringBuilder = new StringBuilder().Append("SELECT ea.ID as AssignmentLocalId, ea.eventID as eventID,eu.userid as userID,eu.email, e.emrsiD as OccurrenceId, 'Assignment' as AssignmentType FROM eventAdmin ea")
            .Append(" inner join event e on e.eventID= ea.eventID")
            .Append(" inner join EMSUser eu on eu.userid= ea.userid")
            .Append(" where eu.userStatusID =1 and ea.emrsID is NULL");
            dataTable = operations.Read(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
            if (dataTable.Rows.Count > 0)
            {
                string token;
                Console.WriteLine(LogHelper.Log(LogTarget.SQL, "\n--Total " + dataTable.Rows.Count + " records found--"));
                Console.WriteLine(LogHelper.Log(LogTarget.API, "\n--Push EventAdmin to EMRS--"));
                LogHelper.Log(LogTarget.API, "API URL :" + System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL") + System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentAPI"));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        EventAdminAssignmentsRequest eventAdminAssignmentsRequest = new EventAdminAssignmentsRequest()
                        {
                            AssignmentLocalId = Convert.ToInt32(dataTable.Rows[i]["AssignmentLocalId"]),
                            OccurrenceId = Convert.ToString(dataTable.Rows[i]["OccurrenceId"]),
                            AssignmentType = Convert.ToString(dataTable.Rows[i]["AssignmentType"]),
                            AssignmentFunctionId = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentFunctionId")),
                            AssignmentRoleId = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentRoleId")),
                            AssignmentStatus = System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentStatus")
                        };

                        GraphWebAPI.GetAzureUserDetails objGetAzureID = new GetAzureUserDetails();
                        string _azureID = await objGetAzureID.GetAzureUserDetailsAsync(Convert.ToString(dataTable.Rows[i]["email"]));
                        if (!string.IsNullOrEmpty(_azureID))
                        {
                            var url = string.Format(System.Configuration.ConfigurationManager.AppSettings.Get("AssignmentAPI"), _azureID);
                            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, EMS2Scope);
                            token = await tokenService.GetToken();
                            LogHelper.Log(LogTarget.API, "Request Parameters :" + Newtonsoft.Json.JsonConvert.SerializeObject(eventAdminAssignmentsRequest));
                            var res = await eMRSAPIs.PushOtherDataToEMRSAsync<EventAdminAssignmentsRequest>(eventAdminAssignmentsRequest, url, token);
                            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(res.ToString());
                            if (myDeserializedClass != null)
                            {
                                LogHelper.Log(LogTarget.API, "Response :" + Newtonsoft.Json.JsonConvert.SerializeObject(myDeserializedClass.assignmentId));
                                stringBuilder = new StringBuilder().Append(String.Format("update eventAdmin set emrsid='{0}' where eventID={1} and userid={2}", Convert.ToString(myDeserializedClass.assignmentId), Convert.ToInt32(dataTable.Rows[i]["eventID"]), Convert.ToInt32(dataTable.Rows[i]["userID"])));
                                operations.Update(LogHelper.Log(LogTarget.SQL, stringBuilder.ToString()), ConfigurationManager.AppSettings.Get("EMSDbConnection"));
                            }
                            //Console.WriteLine(LogHelper.Log(LogTarget.API, "User found for" + Convert.ToString(dataTable.Rows[i]["email"]) + "  In Azure"));
                        }
                        else 
                        {
                            Console.WriteLine(LogHelper.Log(LogTarget.API, "No User found for " + Convert.ToString(dataTable.Rows[i]["email"]) + "  In Azure"));
                        }
                       
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(LogHelper.Log(LogTarget.API, "Synch failed for EventID: " + Convert.ToString(dataTable.Rows[i]["AssignmentLocalId"]) + "  \nError:" + ex.Message));
                    }

                    ProgressBar.DrawProgressBar(i + 1, dataTable.Rows.Count);
                }

            }
        }

        public class EventAdminAssignmentsRequest
        {
            public int AssignmentLocalId { get; set; }
            public string OccurrenceId { get; set; }
            public string AssignmentType { get; set; }
            public int AssignmentFunctionId { get; set; }
            public int AssignmentRoleId { get; set; }
            public string AssignmentStatus { get; set; }
            public int ApplicationId { get => _ = 1; }
        }

        //cantor method
//        select(eventid + userid) * (eventid + userid +1) / 2 + userid, eventID, userID
//from eventAdmin
//order by 1


    }
}
