﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomLogs
{
   public enum LogTarget
    {
        API, SQL
    }
}
