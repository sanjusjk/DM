﻿using System;
using System.IO;

namespace CustomLogs
{
    public abstract class LogBase
    {
        protected readonly object lockObj = new object();
        public abstract void Log(string message);

    }
    public class APILogger : LogBase
    {
        public string filePath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\APILog.txt";
        public override void Log(string message)
        {
            lock (lockObj)
            {
                using (StreamWriter w = File.AppendText(filePath))
                {
                    w.WriteLine(message);
                }
            }
        }
    }
    public class SQLLogger : LogBase
    {
        public string filePath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\SQLLog.txt";
        public override void Log(string message)
        {
            lock (lockObj)
            {
                using (StreamWriter w = File.AppendText(filePath))
                {
                    w.WriteLine(message);
                }
            }
        }
    }
}
