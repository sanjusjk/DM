﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomLogs
{
    public static class LogHelper
    {
        private static LogBase logger = null;
        public static string Log(LogTarget target, string message)
        {
            
            switch (target)
            {
                case LogTarget.API:
                    logger = new APILogger();
                    logger.Log(message);
                    break;
                case LogTarget.SQL:
                    logger = new SQLLogger();
                    logger.Log(message);
                    break;
                default:
                    return message;
            }

            return message;

        }
    }
}
