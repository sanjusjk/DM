﻿
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Configuration;
using EMRSAPI;
using Newtonsoft.Json;
using CustomLogs;

namespace GraphWebAPI
{

    #region Model
    public class WhoUser
    {
        public List<object> businessPhones { get; set; }
        public string displayName { get; set; }
        public object givenName { get; set; }
        public object jobTitle { get; set; }
        public string mail { get; set; }
        public object mobilePhone { get; set; }
        public object officeLocation { get; set; }
        public object preferredLanguage { get; set; }
        public object surname { get; set; }
        public string userPrincipalName { get; set; }
        public string id { get; set; }
    }

    public class NonWhoUser
    {
        [JsonProperty(PropertyName = "@odata.context")]
        public string context { get; set; }
        [JsonProperty(PropertyName = "@odata.nextLink")]
        public string nextLink { get; set; }
        public List<WhoUser> value { get; set; }
    }

    #endregion
    public class GetAzureUserDetails
    {
        private static readonly string EMS2ClientId = ConfigurationManager.AppSettings["EMSClientId"].ToString();
        private static readonly string EMS2ClientSecret = ConfigurationManager.AppSettings["EMSClientSecret"].ToString();
        private static readonly string GraphAPIScope = ConfigurationManager.AppSettings["GraphAPIScope"].ToString();
        private static readonly string APITokenURL = ConfigurationManager.AppSettings["GraphAPITokenURL"].ToString();
        private static EMRSAPI.Interface.ITokenService tokenService;
        public GetAzureUserDetails()
        {
            tokenService = new EMRSTokenService(EMS2ClientId, EMS2ClientSecret, APITokenURL, GraphAPIScope);
        }

        public async System.Threading.Tasks.Task<T> GetAzureUserAsync<T>(string user, string token)
        {
            using (var client = new HttpClient())
            {
                if (user.Contains("@who.int"))
                {
                    client.BaseAddress = new Uri(string.Format("https://graph.microsoft.com/v1.0/users/{0}", user));
                }
                else 
                {
                    client.BaseAddress = new Uri(string.Format("https://graph.microsoft.com/v1.0/users?$filter=mail eq '{0}'", user));
                }
                    
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Convert.ToString(token));
                var response = await client.GetAsync(string.Format(Convert.ToString(client.BaseAddress), user));
                if (response.IsSuccessStatusCode)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<T>(res);
                }
                else
                {
                    throw new ApplicationException(response.ReasonPhrase);
                }
            }
        }
        public async Task<string> GetAzureUserDetailsAsync(string user)
        {
            string AzureID = "";
            try
            {
                string EMS2token = await tokenService.GetToken();
                if (user.Contains("@who.int"))
                {
                    WhoUser whoUser = await GetAzureUserAsync<WhoUser>(user, EMS2token);
                    if(whoUser!=null)
                    {
                        AzureID = whoUser.id;
                    }

                }
                else
                {
                    NonWhoUser nonWhoUser = await GetAzureUserAsync<NonWhoUser>(user, EMS2token);
                    if (nonWhoUser != null)
                    {
                        if (nonWhoUser.value != null && nonWhoUser.value.Count > 0)
                        {
                            foreach (var d in nonWhoUser.value)
                            {

                                AzureID = d.id;

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Log(LogTarget.API, "\n Graph API Error (GetAzureUserID) "+ user + " :" + ex.Message);
            }
            return AzureID;
        }

        public string GetAzureUserID(string user)
        {
            try
            {
                string AzureID = "";

                if (user.Contains("@who.int"))
                {

                    Task<WhoUser> _WhoUserData = GetUserDataValue(user);
                    if (_WhoUserData != null)
                    {
                        AzureID = _WhoUserData.Result.id;
                    }


                }
                else
                {

                    //root
                    Task<NonWhoUser> _nonWhoUserDataData = GetUserDataRoot(user);
                    if (_nonWhoUserDataData != null)
                    {
                        if (_nonWhoUserDataData.Result.value != null && _nonWhoUserDataData.Result.value.Count > 0)
                        {
                            foreach (var d in _nonWhoUserDataData.Result.value)
                            {

                                AzureID = d.id;

                            }
                        }
                    }


                }

                return AzureID;
            }
            catch (Exception ex)
            {
                LogHelper.Log(LogTarget.API, "\n Graph API Error (GetAzureUserID) :" + ex.Message);
                throw ex;
            }
        }

        private async static Task<WhoUser> GetUserDataValue(string user)
        {
            try
            {
                WhoUser dObjects = new WhoUser();
                string EMS2token = await tokenService.GetToken();
                var URL = string.Format("https://graph.microsoft.com/v1.0/users/{0}", user);

                HttpClient client = new HttpClient
                {
                    BaseAddress = new Uri(URL)
                };

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

                //Add authorization with token generated above
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", EMS2token);

                // data response.
                HttpResponseMessage response = await client.GetAsync(URL);

                // Blocking call! Program will wait here until a response is received or a timeout occurs.
                if (response.IsSuccessStatusCode)
                {
                    var PostResponse = response.Content.ReadAsStringAsync().Result;
                    dObjects = JsonConvert.DeserializeObject<WhoUser>(PostResponse);
                }

                return dObjects;
            }
            catch (Exception ex)
            {
                LogHelper.Log(LogTarget.API, "\n Graph API Error (GetUserDataValue):" + ex.Message);
                throw ex;
            }
        }

        private async static Task<NonWhoUser> GetUserDataRoot(string user)
        {
            try
            {
                NonWhoUser dObjects = new NonWhoUser();
                string EMS2token = await tokenService.GetToken();
                var URL = string.Format("https://graph.microsoft.com/v1.0/users?$filter=mail eq '{0}'", user);

                HttpClient client = new HttpClient
                {
                    BaseAddress = new Uri(URL)
                };

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

                //Add authorization with token generated above
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", EMS2token);

                // data response.
                HttpResponseMessage response = await client.GetAsync(URL);

                // Blocking call! Program will wait here until a response is received or a timeout occurs.
                if (response.IsSuccessStatusCode)
                {
                    var PostResponse = response.Content.ReadAsStringAsync().Result;
                    dObjects = JsonConvert.DeserializeObject<NonWhoUser>(PostResponse);
                }

                return dObjects;
            }
            catch (Exception ex)
            {
                LogHelper.Log(LogTarget.API, "\n Graph API Error (GetUserDataRoot) :" + ex.Message);
                throw ex;
            }
        }
    }
}
