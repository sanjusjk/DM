﻿using EMRSAPI.Interface;
using EMRSAPI.Model;
using EMRSAPI.RefDataResponse;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace EMRSAPI
{
    public class EMRSAPIServices : IEMRSAPIs
    {

        public EMRSAPIServices()
        {

        }
        public async System.Threading.Tasks.Task<Root> PushDataToEMRSAsync<T>(object model, string url, string token)
        {
            Root myDeserializedClass = new Root();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL"));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Convert.ToString(token));
                var response = await client.PostAsJsonAsync(url, (T)model);
                if (response.IsSuccessStatusCode)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    myDeserializedClass = JsonConvert.DeserializeObject<Root>(res);
                    if (myDeserializedClass == null)
                    {
                        throw new ApplicationException(response.ReasonPhrase);
                    }
                }
                else
                {
                    var res = await response.Content.ReadAsStringAsync();
                    throw new ApplicationException(res);
                }
            }
            return myDeserializedClass;
        }
        public async System.Threading.Tasks.Task<object> PushOtherDataToEMRSAsync<T>(object model, string url, string token)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(System.Configuration.ConfigurationManager.AppSettings.Get("EMRSRootURL"));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Convert.ToString(token));
                var response = await client.PostAsJsonAsync(url, (T)model);
                if (response.IsSuccessStatusCode)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    return res;
                }
                else
                {
                    var res = await response.Content.ReadAsStringAsync();
                    throw new ApplicationException(res);
                }
            }

        }
    }
}
