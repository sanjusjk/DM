﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.RefDataResponse
{
    public class Value
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public object EmsId { get; set; }
        public string EmsCode { get; set; }
        public string EmsName { get; set; }
        public object VshocId { get; set; }
        public string vShocCode { get; set; }
        public string vShocName { get; set; }
        public object SyncToEms { get; set; }
        public object SyncTovShoc { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public DateTime? EmsLastSyncDateTime { get; set; }
        public DateTime? VshocLastSyncDateTime { get; set; }
        public object OrderId { get; set; }
        public string applyPermissions { get; set; }
        public object EmsSyncErrorMessage { get; set; }
        public object Ems2SyncErrorMessage { get; set; }
    }

    public class Root
    {
        public Value value { get; set; }
    }

}
