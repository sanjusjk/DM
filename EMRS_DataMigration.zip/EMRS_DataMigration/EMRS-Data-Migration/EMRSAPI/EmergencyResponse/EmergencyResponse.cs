﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.EmergencyResponse
{
    public class Value
    {
        public string id { get; set; }
        public string occurrenceName { get; set; }
        public object description { get; set; }
        public string occurrenceType { get; set; }
        public string driveId { get; set; }
        public object archiveDriveId { get; set; }
        public object emsOccurrenceDisplayId { get; set; }
        public bool isActive { get; set; }
        public bool isArchived { get; set; }
        public object createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public object modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public object emsLastSyncDateTime { get; set; }
        public object vshocLastSyncDateTime { get; set; }
        public int sourceReferenceId { get; set; }
    }

    public class Root
    {
        public Value value { get; set; }
    }
}
