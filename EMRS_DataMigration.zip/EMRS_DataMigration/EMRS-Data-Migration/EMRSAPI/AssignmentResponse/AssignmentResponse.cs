﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.AssignmentResponse
{
    public class Root
    {
        public string assignmentId { get; set; }
        public string message { get; set; }
    }
}
