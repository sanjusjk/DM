﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.Model
{
    internal sealed class Utilities
    {
        static Utilities()
        {
            eMRSToken = new EMRSToken();
        }
        public static EMRSToken eMRSToken;
    }
}
