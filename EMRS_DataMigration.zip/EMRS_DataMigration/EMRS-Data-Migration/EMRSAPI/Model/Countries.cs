﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.Model
{
    public class Countries
    {
        public int Type { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Comments { get; set; }
        public bool? IsOfficialUnCountry { get; set; }
        public bool? IsWhoMemberState { get; set; }
        public string OfficialName { get; set; }
        public string ShortName { get; set; }
        public string Iso2Code { get; set; }
        public string Iso3Code { get; set; }
        public string UnCode { get; set; }
        public string Adm0Code { get; set; }
        public int RegionId { get; set; }
        public string UnicefRegion { get; set; }
        public int? SovereignCountryId { get; set; }
        public string Timezone { get; set; }
        public int? Offset { get; set; }
        public string PhoneCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? OrderId { get; set; }
        public string applyPermissions { get; set; }
        public bool SyncToEms { get; set; }
        public int? EmsId { get; set; }
        public string EmsCode { get; set; }
        public string EmsName { get; set; }
        public bool SyncTovShoc { get; set; }
        public int? VshocId { get; set; }
        public string vShocCode { get; set; }
        public string vShocName { get; set; }
    }
}
