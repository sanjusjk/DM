﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMRSAPI.Model
{
    public class SystemPosition
    {
        public int Type { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ApplicationId { get; set; }
        public int? OrderId { get; set; }
        public string applyPermissions { get; set; }
        public bool SyncToEms { get; set; }
        public int? EmsId { get; set; }
        public string EmsCode { get; set; }
        public string EmsName { get; set; }
        public bool SyncTovShoc { get; set; }
        public int? VshocId { get; set; }
        public string vShocCode { get; set; }
        public string vShocName { get; set; }
    }
}
