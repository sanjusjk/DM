﻿using EMRSAPI.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EMRSAPI.Interface
{
   public interface IEMRSAPIs
    {
        Task <RefDataResponse.Root> PushDataToEMRSAsync<T>(object model, string url, string token);
        Task<object> PushOtherDataToEMRSAsync<T>(object model, string url, string token);
    }
}
