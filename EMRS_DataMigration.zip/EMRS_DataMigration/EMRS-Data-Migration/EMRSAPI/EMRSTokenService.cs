﻿using System;
using EMRSAPI.Model;
using System.Net.Http;
using System.Net.Http.Headers;
namespace EMRSAPI
{
    public class EMRSTokenService : Interface.ITokenService
    {
        private readonly string ClientId = "";
        private readonly string ClientSecret = "";
        private readonly string TokenUrl = "";
        private readonly string Scope = "";

        public EMRSTokenService(string clientId, string clientSecret, string tokenUrl, string scope)
        {
            ClientId = clientId;
            ClientSecret = clientSecret;
            TokenUrl = tokenUrl;
            Scope = scope;
            Model.Utilities.eMRSToken = new EMRSToken();
        }
        public async System.Threading.Tasks.Task<string> GetToken()
        {
            if (!Model.Utilities.eMRSToken.IsValidAndNotExpiring)
            {
                Model.Utilities.eMRSToken = await this.GetNewAccessToken();
            }
            return Model.Utilities.eMRSToken.AccessToken;
        }
        private async System.Threading.Tasks.Task<EMRSToken> GetNewAccessToken()
        {
            var client = new HttpClient();
            var clientCreds = System.Text.Encoding.UTF8.GetBytes($"{this.ClientId}:{this.ClientSecret}");
            client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Basic", System.Convert.ToBase64String(clientCreds));
            var postMessage = new System.Collections.Generic.Dictionary<string, string>
            {
                { "grant_type", "client_credentials" },
                { "scope", Scope }
            };
            var request = new HttpRequestMessage(HttpMethod.Post, this.TokenUrl)
            {
                Content = new FormUrlEncodedContent(postMessage)
            };
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                Utilities.eMRSToken = Newtonsoft.Json.JsonConvert.DeserializeObject<EMRSToken>(json);
                Utilities.eMRSToken.ExpiresAt = DateTime.UtcNow.AddSeconds(Utilities.eMRSToken.ExpiresIn);
            }
            else
            {
                throw new ApplicationException("Unable to retrieve access token from emrs");
            }
            return Utilities.eMRSToken;
        }
    }
}
