# EMRS-Data-Migration
Console app to migrate data (not documents) into EMRS
- Reference Data (countries, hazard, disease-condition, aetilogy, etc.)
- Contacts
- Events, Events Groups
- Emergencies
- Deployment Assignents
- to be completed... 